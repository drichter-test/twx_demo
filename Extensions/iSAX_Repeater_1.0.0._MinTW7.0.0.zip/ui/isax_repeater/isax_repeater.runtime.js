﻿TW.Runtime.Widgets.isax_repeater = function () {
    var thisWidget = this,
        fixedMashupWidth = 0,
        fixedMashupHeight = 0,
        cellsPerRowForHorizontalWrap = 0,
        cellsContainer,
        cellsTableEl,
        dataInfotable,
        dataRows,
        nDataRows,
        cellTable = [],
        needUpdateCell = false,
        allowSelection = false,
        widgetHeight,
        widgetWidth,
        repeaterView,
        selectedRowIndices,
        cellBorderWidth = 0,
        cacheId = TW.uniqueId(),
        dataVer = 0,
        itemLoadBehavior = 'load-destroy-on-demand',
        loadedAllItems = false,
        reusableCells = [],
        resizeId = 0,
        scrollId = 0,
        cellCache = {},
        lastScrollPos = 0,
        renderedCellIndices = [],
        effectiveMashupWidth,
        effectiveMashupHeight,
        renderQueue = [],
        inTimeoutWaitingToRender = 0,
        newDataIsWaiting = false,
        lastUpdatePropertyInfo = undefined,
        reuseMashupsSetting = false,
        selectionWidth,
        selectionHeight,
        initCellsCount = 0,
        nHWTableRowsCount = 0,
        nHWLastRowTableCellsCount = 0,
        handleResize = true,
        lastWidth,
        lastHeight,
        hideInnerScrollbars = false,
        overflow;

    var removeCellForRowAtIndex = function (index, reuseCell) {
        if (cellTable[index]) {
            cellTable[index].loaded = false;
            var cellId = '#content-' + cellTable[index].itemId;
            var $cell, $mashup;
            if (cellCache[cellId]) {
                $cell = cellCache[cellId];
            } else {
                $cell = cellCache[cellId] = $(cellId);
            }
            $mashup = $cell.children('.mashup-item');
            if ($mashup.length > 0) {
                if (reuseMashupsSetting === true && reuseCell) {
                    $mashup.detach();
                    reusableCells.push($mashup);
                    //console.log('added, reusable cells = ' + reusableCells.length);
                } else {
                    // remove cell from rendered cell list
                    if (renderedCellIndices.indexOf(index) > -1) {
                        renderedCellIndices.splice(renderedCellIndices.indexOf(index),1);
                    }
                    try {
                        $mashup.detach();
                        $mashup.mashup('destroy');
                    } catch (err) {
                    }
                }
            }
        }
    };

    var renderCellForRowAtIndex = function (index, reuseMashup) {
        //console.log('rendering cell ' + index);
        try {
            var mashupSpec = {};
            mashupSpec.mashupName = thisWidget.getProperty('Mashup');
            mashupSpec.mashupParameters = {};
            mashupSpec.cacheId = cacheId;
            mashupSpec.async = false;

            var mashupParameters = thisWidget.properties['MashupParameters'];
            if (mashupParameters === undefined)
                mashupParameters = [];

            var nParams = mashupParameters.length;

            for (var paramNo = 0; paramNo < nParams; paramNo++) {
                var paramInfo = mashupParameters[paramNo],
                    propName = paramInfo.ParameterName,
                    fldName = thisWidget.getProperty(propName),
                    propValue;
                if (fldName === 'ALL_FIELDS') {
                    propValue = JSON.parse(JSON.stringify(dataInfotable));
                    propValue.rows.push(dataRows[index]);
                } else {
                    propValue = dataRows[index][thisWidget.getProperty(propName)];
                }
                if (propValue !== undefined) {
                    mashupSpec.mashupParameters[propName] = propValue;
                }
            }
            // Add index to rendered cell array if it isn't already in it.
            if (renderedCellIndices.indexOf(index) < 0) {
                renderedCellIndices.push(index);
            }
            if (reuseMashupsSetting === true && reuseMashup && cellTable[index].loaded) {
                var cellId = '#content-' + cellTable[index].itemId;
                var $cell, $mashup;
                if (cellCache[cellId]) {
                    $cell = cellCache[cellId];
                } else {
                    $cell = cellCache[cellId] = $(cellId);
                }
                $mashup = $cell.children('.mashup-item');
                //console.log('setting parameters for cell ' + index);
                $mashup.mashup('reuseAndSetParameters', mashupSpec.mashupParameters);
                $mashup.mashup('reloadEvents');
            } else {
                cellTable[index].loaded = true;
                var cellId = '#content-' + cellTable[index].itemId;
                var $cell, $mashup;
                if (cellCache[cellId]) {
                    $cell = cellCache[cellId];
                } else {
                    $cell = cellCache[cellId] = $(cellId);
                }
                if (reuseMashupsSetting === true && reuseMashup && reusableCells.length > 0) {
                    $mashup = reusableCells.pop();
                    //console.log('reused cell, reusable cells = ' + reusableCells.length);
                    $cell.append($mashup);
                    $mashup.mashup('reuseAndSetParameters', mashupSpec.mashupParameters);
                    $mashup.mashup('reloadEvents');
                } else {
                    if (reuseMashupsSetting === true && reuseMashup === false && reusableCells.length > 0) {
                        reusableCells.pop();
                    }
                    $mashup = $('<div class="mashup-item"></div>');
                    $cell.append($mashup);
                    $mashup.mashup(mashupSpec);
                    //console.log('created new mashup instance');
                }
            }
        } catch (err) {
        }
    };

    var initCells = function (resetScroll, onResize, reuseMashup) {

        var cellsHtml = '',
            itemRowHtml = '',
            selectorsHtml = '',
            tblId,
            newCellsPerRowForHorizontalWrap,
            vertWidth,
            horizHeight;

        effectiveMashupWidth = fixedMashupWidth + cellBorderWidth;
        effectiveMashupHeight = fixedMashupHeight + cellBorderWidth;
        vertWidth = thisWidget.getProperty('SelectionWidth', 25);
        horizHeight = thisWidget.getProperty('SelectionHeight', 25);

        // make sure we know the height first - in case data comes in before the resize event.  Without this, the data is refreshed twice
        if( lastWidth === undefined || lastHeight === undefined ) {
            lastWidth = thisWidget.jqElement.outerWidth();
            lastHeight = thisWidget.jqElement.outerHeight();
            widgetWidth = thisWidget.jqElement.width();
            widgetHeight = thisWidget.jqElement.height();
        }

        if( onResize === true ) {
            handleResize = false;
            //console.log('handleResize set to false in initCells( resetScroll:' + resetScroll + ', onResize:' + onResize + ', reuseMashup:' + reuseMashup);
            setTimeout(function () {
                handleResize = true;
                //console.log('   after 1 sec, handleResize set to true in initCells');
                // attempt to resize based on the current window size, if nothing has changed, it'll just skip this
                // if the window has changed size within a second of the last resize event, this will catch it.
                thisWidget.resize(thisWidget.jqElement.outerWidth(), thisWidget.jqElement.outerHeight());
            }, 1000);
        }

      //console.log('initCells ' + thisWidget.jqElementId + ' , initCellsCount: ' + initCellsCount + ', onResize: ' + onResize + ', cellTable.length:' + cellTable.length + ', nDataRows:' + nDataRows);
        if (initCellsCount > 0) {
            if (onResize && repeaterView == 'horizontal-wrap') {
                newCellsPerRowForHorizontalWrap = Math.floor(widgetWidth / effectiveMashupWidth);
                if (cellsPerRowForHorizontalWrap == newCellsPerRowForHorizontalWrap) {
                    if (cellTable.length == nDataRows) {
                        if (selectedRowIndices !== undefined) {
                            updateSelections(selectedRowIndices);
                        }
                        updateCells(true, true, reuseMashup);
                        return;
                    }
                } else {
                    loadedAllItems = false;
                }
            } else {
                if (cellTable.length == nDataRows) {

                    if (selectedRowIndices !== undefined) {
                        updateSelections(selectedRowIndices);
                    }
                    updateCells(true, true, reuseMashup);
                    return;

                } else if (cellTable.length < nDataRows) {

                    if (repeaterView == 'vertical') {

                        for (var i = cellTable.length; i < nDataRows; i += 1) {
                            var rowId = thisWidget.jqElementId + '-row-' + (i + 1);
                            cellsHtml += '<tr id="' + rowId + '" class="repeater-item repeater-item-unselected" row-index="' + i + '" item-selector-id="item-selector-' + rowId + '">' + (allowSelection === true && vertWidth > 0 ? '<td class="item-selector"><div class="item-selector-wrapper" id="item-selector-' + rowId + '" row-index="' + i + '" item-id="' + rowId + '"><span class="item-selector-icon"></span></div></td>' : '') + '<td id="mashup-content-cell-' + rowId + '" class="mashup-content-cell"><div class="cellposition"><div class="selection-test-div"></div><div id="content-' + rowId + '" class="content-wrapper"></div></div></td></tr>';
                            cellTable.push({
                                itemId: rowId,
                                loaded: false
                            });
                        }
                        cellsTableEl.append(cellsHtml);
                        if (selectedRowIndices !== undefined) {
                            updateSelections(selectedRowIndices);
                        }
                        updateCells(true, true, reuseMashup);
                        return;

                    } else if (repeaterView == 'horizontal') {

                        for (var i = cellTable.length; i < nDataRows; i += 1) {
                            var rowId = thisWidget.jqElementId + '-row-' + (i + 1);
                            selectorsHtml += (allowSelection === true ? '<td id="item-selector-' + rowId + '" class="item-selector repeater-item-unselected" row-index="' + i + '" item-id="mashup-content-cell-' + rowId + '"><div class="item-selector-wrapper"><span class="item-selector-icon"></span></div></td>' : '');
                            cellsHtml += '<td id="mashup-content-cell-' + rowId + '" class="mashup-content-cell repeater-item repeater-item-unselected" item-selector-id="item-selector-' + rowId + '" row-index="' + i + '"><div class="cellposition"><div class="selection-test-div"></div><div id="content-' + rowId + '" class="content-wrapper"></div></div></td>';
                            cellTable.push({
                                itemId: rowId,
                                loaded: false
                            });
                        }
                        cellsTableEl.find('.repeater-row:first').append(cellsHtml);

                        if (allowSelection === true && horizHeight > 0) {
                            cellsTableEl.find('.item-selector-row:first').append(selectorsHtml);
                        }
                        if (selectedRowIndices !== undefined) {
                            updateSelections(selectedRowIndices);
                        }
                        updateCells(true, true, reuseMashup);
                        return;

                    } else if (repeaterView == 'horizontal-wrap') {
                        var nRowsToAdd = Math.ceil(nDataRows / cellsPerRowForHorizontalWrap) - nHWTableRowsCount;
                        var nCellsToAdd = nDataRows - cellTable.length;
                        var curSelRow, curItemRow, selectorCell, itemCell, rowId, rowIndex, rowsContainer;
                        //console.log('nRowsToAdd=' + nRowsToAdd);
                        //console.log('nCellsToAdd=' + nCellsToAdd);
                        rowIndex = cellTable.length;
                        rowsContainer = cellsTableEl.children('tbody');
                        //console.log('nRowsToAdd:' + nRowsToAdd + ', nCellsToAdd:' + nCellsToAdd + ', nHWTableRowsCount:' + nHWTableRowsCount + ', cellsPerRowForHorizontalWrap:' + cellsPerRowForHorizontalWrap);
                        while (nCellsToAdd > 0) {
                            // if we didn't have any rows in the table at first rowsContainer will have no entries, since tbody isn't added until the first row is added
                            if( rowsContainer.length == 0 ) {
                                rowsContainer = cellsTableEl.children('tbody');
                            }
                            if (nHWTableRowsCount > 0 && nHWLastRowTableCellsCount < cellsPerRowForHorizontalWrap) {
                                curSelRow = rowsContainer.children('.item-selector-row:last');
                                curItemRow = rowsContainer.children('.repeater-row:last');
                            } else {
                                nHWLastRowTableCellsCount = 0;

                                if (allowSelection === true && horizHeight > 0) {
                                    curSelRow = $('<tr class="item-selector-row"></tr>');
                                    cellsTableEl.append(curSelRow);
                                }
                                curItemRow = $('<tr class="repeater-row"></tr>');
                                cellsTableEl.append(curItemRow);
                                nHWTableRowsCount += 1;
                            }

                            rowId = thisWidget.jqElementId + '-row-' + (rowIndex + 1);

                            if (allowSelection === true && horizHeight > 0) {
                                selectorCell = $('<td id="item-selector-' + rowId + '" class="item-selector repeater-item-unselected" row-index="' + rowIndex + '" item-id="mashup-content-cell-' + rowId + '"><div class="item-selector-wrapper"><span class="item-selector-icon"></span></div></td>');
                                curSelRow.append(selectorCell);
                            }
                            itemCell = $('<td id="mashup-content-cell-' + rowId + '" class="mashup-content-cell repeater-item repeater-item-unselected" row-index="' + rowIndex + '" item-selector-id="item-selector-' + rowId + '"><div class="cellposition"><div class="selection-test-div"></div><div id="content-' + rowId + '" class="content-wrapper"></div></div></td>');
                            curItemRow.append(itemCell);

                            cellTable.push({
                                itemId: rowId,
                                loaded: false
                            });

                            nHWLastRowTableCellsCount += 1;
                            rowIndex += 1;
                            nCellsToAdd -= 1;
                        }

                        //console.log('nHWTableRowsCount=' + nHWTableRowsCount + ', nHWLastRowTableCellsCount=' + nHWLastRowTableCellsCount);

                        if (selectedRowIndices !== undefined) {
                            updateSelections(selectedRowIndices);
                        }
                        updateCells(true, true, reuseMashup);
                        return;
                    }
                } else {
                    if (repeaterView == 'vertical') {

                        for (var i = cellTable.length - 1; i >= nDataRows; i -= 1) {
                            var rowId = thisWidget.jqElementId + '-row-' + (i + 1);
                            removeCellForRowAtIndex(i, false);
                            $('#' + rowId).remove();
                            var cellId = '#content-' + cellTable[i].itemId;
                            delete cellCache[cellId];
                            cellTable.splice(i, 1);
                        }

                        if (selectedRowIndices !== undefined) {
                            updateSelections(selectedRowIndices);
                        }
                        updateCells(true, true, reuseMashup);
                        return;

                    } else if (repeaterView == 'horizontal') {

                        for (var i = cellTable.length - 1; i >= nDataRows; i -= 1) {
                            var rowId = thisWidget.jqElementId + '-row-' + (i + 1);
                            removeCellForRowAtIndex(i, false);
                            $('#mashup-content-cell-' + rowId).remove();
                            $('#item-selector-' + rowId).remove();
                            var cellId = '#content-' + cellTable[i].itemId;
                            delete cellCache[cellId];
                            cellTable.splice(i, 1);
                        }

                        if (selectedRowIndices !== undefined) {
                            updateSelections(selectedRowIndices);
                        }
                        updateCells(true, true, reuseMashup);
                        return;

                    } else if (repeaterView == 'horizontal-wrap') {
                        var nRowsToRemove = nHWTableRowsCount - Math.ceil(nDataRows / cellsPerRowForHorizontalWrap);
                        var nCellsToRemove = cellTable.length - nDataRows;
                        //console.log('nRowsToRemove=' + nRowsToRemove);
                        //console.log('nCellsToRemove=' + nCellsToRemove);
                        var rowsContainer = cellsTableEl.children('tbody');

                        for (var i = cellTable.length - 1; i >= nDataRows; i -= 1) {
                            var rowId = thisWidget.jqElementId + '-row-' + (i + 1);
                            removeCellForRowAtIndex(i, false);
                            $('#mashup-content-cell-' + rowId).remove();
                            $('#item-selector-' + rowId).remove();
                            var cellId = '#content-' + cellTable[i].itemId;
                            delete cellCache[cellId];
                            cellTable.splice(i, 1);
                        }

                        while (nRowsToRemove > 0) {
                            rowsContainer.children('.item-selector-row:last').remove();
                            rowsContainer.children('.repeater-row:last').remove();
                            nHWTableRowsCount -= 1;
                            nRowsToRemove -= 1;
                        }

                        nHWLastRowTableCellsCount = rowsContainer.children('.repeater-row:last').children('.mashup-content-cell').length;

                        if (selectedRowIndices !== undefined) {
                            updateSelections(selectedRowIndices);
                        }
                        updateCells(true, true, reuseMashup);
                        return;
                    }
                }
            }
        }

        initCellsCount += 1;

        cellCache = {};
        removeAllCells();
        tblId = 'a' + TW.createUUID();
        cellsTableEl = $('<table border="0" cellpadding="0" cellspacing="0" id="' + tblId + '" class="repeater-items ' + (repeaterView === 'horizontal-wrap' ? 'horizontal-wrap' : '') + '"></table>');
        cellsContainer.append(cellsTableEl);

        if (repeaterView === 'vertical') {
            cellsTableEl.addClass('vertical');
            for (var i = 0; i < nDataRows; i += 1) {
                var rowId = thisWidget.jqElementId + '-row-' + (i + 1);
                cellsHtml += '<tr id="' + rowId + '" class="repeater-item repeater-item-unselected" row-index="' + i + '" item-selector-id="item-selector-' + rowId + '">' + (allowSelection === true && vertWidth > 0 ? '<td class="item-selector"><div class="item-selector-wrapper" id="item-selector-' + rowId + '" row-index="' + i + '" item-id="' + rowId + '"><span class="item-selector-icon"></span></div></td>' : '') + '<td id="mashup-content-cell-' + rowId + '" class="mashup-content-cell"><div class="cellposition"><div class="selection-test-div"></div><div id="content-' + rowId + '" class="content-wrapper"></div></div></td></tr>';
                cellTable.push({
                    itemId: rowId,
                    loaded: false
                });
            }

        } else if (repeaterView === 'horizontal-wrap') {
            nHWTableRowsCount = 0;
            cellsPerRowForHorizontalWrap = Math.floor(widgetWidth / effectiveMashupWidth) || 1;

            for (var i = 0; i < nDataRows; i += 1) {
                var rowId = thisWidget.jqElementId + '-row-' + (i + 1);

                if (i % cellsPerRowForHorizontalWrap === 0) {
                    if (i !== 0) {
                        if (allowSelection === true) {
                            selectorsHtml += '</tr>';
                        }
                        itemRowHtml += '</tr>';
                        cellsHtml += (allowSelection === true ? selectorsHtml : '') + itemRowHtml;
                        // cellsHtml += '</tr>';
                    }
                    if (allowSelection === true) {
                        selectorsHtml = '<tr class="item-selector-row">';
                    }
                    itemRowHtml = '<tr class="repeater-row">';
                    nHWTableRowsCount += 1;
                    nHWLastRowTableCellsCount = 0;
                    // cellsHtml += '<tr id="' + rowId + '" class="repeater-item repeater-item-unselected" row-index="' + i + '">';
                }
                if (allowSelection === true) {
                    selectorsHtml += '<td id="item-selector-' + rowId + '" class="item-selector repeater-item-unselected" row-index="' + i + '" item-id="mashup-content-cell-' + rowId + '"><div class="item-selector-wrapper"><span class="item-selector-icon"></span></div></td>';
                }
                itemRowHtml += '<td id="mashup-content-cell-' + rowId + '" class="mashup-content-cell repeater-item repeater-item-unselected" row-index="' + i + '" item-selector-id="item-selector-' + rowId + '"><div class="cellposition"><div class="selection-test-div"></div><div id="content-' + rowId + '" class="content-wrapper"></div></div></td>';
                nHWLastRowTableCellsCount += 1;
                cellTable.push({
                    itemId: rowId,
                    loaded: false
                });
            }

            if (nDataRows > 0) {
                if (allowSelection === true) {
                    selectorsHtml += '</tr>';
                }
                itemRowHtml += '</tr>';
                cellsHtml += (allowSelection === true ? selectorsHtml : '') + itemRowHtml;
            }

            //console.log('nHWTableRowsCount=' + nHWTableRowsCount + ', nHWLastRowTableCellsCount=' + nHWLastRowTableCellsCount);

        } else if (repeaterView === 'horizontal') {

            cellsTableEl.addClass('horizontal');
            cellsHtml += '<tr class="repeater-row">';
            for (var i = 0; i < nDataRows; i += 1) {
                var rowId = thisWidget.jqElementId + '-row-' + (i + 1);
                selectorsHtml += (allowSelection === true ? '<td id="item-selector-' + rowId + '" class="item-selector repeater-item-unselected" row-index="' + i + '" item-id="mashup-content-cell-' + rowId + '"><div class="item-selector-wrapper"><span class="item-selector-icon"></span></div></td>' : '');
                cellsHtml += '<td id="mashup-content-cell-' + rowId + '" class="mashup-content-cell repeater-item repeater-item-unselected" row-index="' + i + '" item-selector-id="item-selector-' + rowId + '"><div class="cellposition"><div class="selection-test-div"></div><div id="content-' + rowId + '" class="content-wrapper"></div></div></td>';
                cellTable.push({
                    itemId: rowId,
                    loaded: false
                });
            }
            cellsHtml += '</tr>';
            if (allowSelection === true && horizHeight > 0) {
                cellsHtml = '<tr class="item-selector-row">' + selectorsHtml + '</tr>' + cellsHtml
            }
        }

        cellsTableEl.append(cellsHtml);
        lastScrollPos = 0;

        if (resetScroll) {
            cellsContainer.scrollTop(0);
            cellsContainer.scrollLeft(0);

        }

        var widthSpecification = ' width: ' + fixedMashupWidth + 'px;';
        var heightSpecification = ' height: ' + fixedMashupHeight + 'px;';
        if (thisWidget.properties.ResponsiveLayout === true && repeaterView === 'vertical') {
            widthSpecification = '';
        }
        if (thisWidget.properties.ResponsiveLayout === true && repeaterView === 'horizontal') {
            heightSpecification = ' height: 100%; ';
        }

        cellsTableEl.prepend(
            '<style>' +
            '#' + thisWidget.jqElementId + ' .mashup-content-cell { ' + heightSpecification + ' ' + widthSpecification + ' }' +
            '#' + thisWidget.jqElementId + ' .item-selector { ' + widthSpecification + ' }' +
            '</style>');

        if (selectedRowIndices !== undefined) {
            updateSelections(selectedRowIndices);
        }

        if (nDataRows > 0 && selectedRowIndices !== undefined && selectedRowIndices.length === 0 && (allowSelection === true) && thisWidget.getProperty('AutoSelectFirstRow') === true) {
            selectedRowIndices = [0];
            updateSelections(selectedRowIndices);
            setTimeout(function () {
                thisWidget.updateSelection('Data', [0]);
            }, 100);
        }

        updateCells(false, false, reuseMashup);
    };

    var clearCellContents = function () {
        var nCells = cellTable.length;
        for (var i = 0; i < nCells; i += 1) {
            removeCellForRowAtIndex(i, false);
        }
    };

    var getVerticalVisibleRange = function (position, viewHeight, cellHeight) {
        var range = {};
        range.start = Math.min(Math.floor(position / cellHeight), Math.max(0, Math.floor((position - viewHeight * 0.5) / cellHeight)));
        range.end = Math.max(Math.floor((position + viewHeight) / cellHeight), Math.min(Math.floor((position + viewHeight + viewHeight * 0.5) / cellHeight), (nDataRows - 1)));
        return range;
    };

    var getHorizontalVisibleRange = function (position, viewWidth, cellWidth) {
        var range = {};
        range.start = Math.min(Math.floor(position / cellWidth), Math.max(0, Math.floor((position - viewWidth * 0.5) / cellWidth)));
        range.end = Math.max(Math.floor((position + viewWidth) / cellWidth), Math.min(Math.floor((position + viewWidth + viewWidth * 0.5) / cellWidth), (nDataRows - 1)));
        return range;
    };

    var getHorizontalWrapVisibleRange = function (position, viewHeight, cellHeight) {
        var range = getVerticalVisibleRange(position,viewHeight,cellHeight);
        range.start = Math.min(range.start * cellsPerRowForHorizontalWrap,(nDataRows - 1));
        range.end = Math.min((range.end+1) * cellsPerRowForHorizontalWrap,(nDataRows - 1));

        //if (viewHeight <= cellHeight) {
        //    range.start = 0;
        //    range.end = 0;
        //} else {
        //    range.start = Math.min(Math.floor(position / cellHeight * cellsPerRowForHorizontalWrap), Math.max(0, Math.floor((position - viewHeight * 0.5) / cellHeight * cellsPerRowForHorizontalWrap)));
        //    range.end = Math.max(Math.floor((position + viewHeight) / cellHeight * cellsPerRowForHorizontalWrap), Math.min(Math.floor((position + viewHeight + viewHeight * 0.5) / cellHeight * cellsPerRowForHorizontalWrap), (nDataRows - 1)));
        //}
        return range;
    };

    var updateCells = function (onresize, forceUpdate, reuseMashup) {
        var nCells = cellTable.length;
        var scrollPos;
        var tblCell,
            removeCells = true,
            renderId;


        effectiveMashupWidth = fixedMashupWidth + cellBorderWidth;
        effectiveMashupHeight = fixedMashupHeight + cellBorderWidth;
        renderQueue = [];

      //console.log('updateCells ' + thisWidget.jqElementId + '  onresize:' + onresize + ', forceUpdate:' + forceUpdate + ', reuseMashup:' + reuseMashup + ', renderedCellIndices.length:' + renderedCellIndices.length + ', nCells:' + nCells + ', loadedAllItems:' + loadedAllItems);
        if (itemLoadBehavior === 'load-all') {
            if (!loadedAllItems) {

                for (var i = renderedCellIndices.length - 1; i >= 0; i -= 1) {
                    var renderedCellIndex = renderedCellIndices[i];
                    removeCellForRowAtIndex(renderedCellIndex, true);
                }

                for (var i = 0; i < nCells; i += 1) {
                    renderQueue.push(i);
                }

                //loadedAllItems = true;
                renderId = dataVer;
                renderCells(renderId, false);
            }
        } else {
            if (itemLoadBehavior === 'load-on-demand' && !onresize) {
                removeCells = false;
            }

            if (repeaterView == 'vertical' || repeaterView == 'horizontal-wrap') {
                scrollPos = cellsContainer.scrollTop();
            } else {
                scrollPos = cellsContainer.scrollLeft();
            }

            var visibleRange;

            if (repeaterView == 'vertical') {
                visibleRange = getVerticalVisibleRange(scrollPos, widgetHeight, effectiveMashupHeight);
            } else if (repeaterView == 'horizontal') {
                visibleRange = getHorizontalVisibleRange(scrollPos, widgetWidth, effectiveMashupWidth);
            } else if (repeaterView == 'horizontal-wrap') {
                if (allowSelection === true) {
                    effectiveMashupHeight += selectionHeight;
                }
                visibleRange = getHorizontalWrapVisibleRange(scrollPos, widgetHeight, effectiveMashupHeight);
            } else {
                visibleRange = {start: 0, end: Math.max(nDataRows - 1, nDataRows)};
            }

            //console.log('range.start=' + visibleRange.start + ', range.end=' + visibleRange.end);

            if (removeCells) {
                //console.log('number of rendered cells: ' + renderedCellIndices.length);
                for (var i = renderedCellIndices.length - 1; i >= 0; i -= 1) {
                    var renderedCellIndex = renderedCellIndices[i];
                    if(renderedCellIndex < visibleRange.start || renderedCellIndex > visibleRange.end){
                        removeCellForRowAtIndex(renderedCellIndex, true);
                    }
                }
            }

            var nCellTableLength = cellTable.length;
            if (scrollPos == 0 || (scrollPos == lastScrollPos) || (scrollPos > 0 && scrollPos > lastScrollPos) || onresize) {

                for (var i = visibleRange.start; i <= visibleRange.end && i < nCellTableLength; i += 1) {
                    tblCell = cellTable[i];
                    if (tblCell !== undefined && (!tblCell.loaded || forceUpdate)) {
                        renderQueue.push(i);
                    }
                }

            } else if (scrollPos > 0 && scrollPos < lastScrollPos) {

                for (var i = visibleRange.end; i >= visibleRange.start; i -= 1) {
                    tblCell = cellTable[i];
                    if (tblCell !== undefined && (!tblCell.loaded || forceUpdate)) {
                        renderQueue.push(i);
                    }
                }

            }
            lastScrollPos = scrollPos;
            renderId = dataVer;
            //console.log('updateCells has ' + renderQueue.length + ' items in render queue');
            renderCells(renderId, reuseMashup);
        }
    };

    var renderCells = function (id, reuseMashup) {
        inTimeoutWaitingToRender++;
        //console.log( 'renderCells, renderQueue.length:' + renderQueue.length);
        setTimeout(function () {
            if (id == dataVer && renderQueue.length > 0) {
                var cellIndex = renderQueue.shift();
                renderCellForRowAtIndex(cellIndex, reuseMashup);
                if (renderQueue.length > 0) {
                    renderCells(id, reuseMashup);
                } else {
                    //console.log('renderQueue.length === 0, number of mashup-content-cell: ' + cellsTableEl.find('.mashup-content-cell').length);
                }
            }
            inTimeoutWaitingToRender--;
            if( inTimeoutWaitingToRender === 0 && newDataIsWaiting ) {
                updateWithWaitingData();
            }
        }, 1);
    };

    var removeAllCells = function () {
        clearCellContents();
        TW.emptyJqElement(cellsContainer);
        cellTable = [];
        cellCache = {};
        renderedCellIndices = [];
    };

    this.runtimeProperties = function () {
        return {
            'needsDataLoadingAndError': true
        };
    };

    this.renderHtml = function () {
        return '<div class="widget-content widget-isax_repeater"><div class="repeater-items-container"></div></div>';
    };

    this.renderStyles = function(){
        var repeaterStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('RepeaterStyle', 'DefaultRepeaterStyle'));
        var repeaterCellStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('RepeaterCellStyle', 'DefaultRepeaterCellStyle'));
        var repeaterUnselectedStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('RepeaterUnselectedStyle', 'DefaultRepeaterUnselectedStyle'));
        var repeaterSelectedStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('RepeaterSelectedStyle', 'DefaultRepeaterSelectedStyle'));

        var repeaterBG = TW.getStyleCssGradientFromStyle(repeaterStyle);
        var repeaterBorder = TW.getStyleCssBorderFromStyle(repeaterStyle);

        var repeaterUnselectedBG = TW.getStyleCssGradientFromStyle(repeaterUnselectedStyle);
        var repeaterUnselectedBorder = TW.getStyleCssBorderFromStyle(repeaterUnselectedStyle);

        var repeaterSelectedBG = TW.getStyleCssGradientFromStyle(repeaterSelectedStyle);
        var repeaterSelectedBorder = TW.getStyleCssBorderFromStyle(repeaterSelectedStyle);

        var repeaterBorderSize = repeaterStyle.lineThickness;
        var repeaterBorderColor = repeaterStyle.lineColor;

        if (repeaterBorderColor === '') {
            repeaterBorderColor = 'transparent';
        }

        if (repeaterBorderSize === '') {
            repeaterBorderSize = 0;
        }

        var repeaterCellBorderSize = repeaterCellStyle.lineThickness;
        var repeaterCellBorderColor = repeaterCellStyle.lineColor;

        if (repeaterCellBorderColor === '') {
            repeaterCellBorderColor = 'rgba(0, 0, 0, 0.0)';
        }

        var repeaterSelectedBorderSize = repeaterSelectedStyle.lineThickness;
        var repeaterSelectedBorderColor = repeaterSelectedStyle.lineColor;

        if (repeaterSelectedBorderSize > 1) {
            repeaterSelectedBorderSize = 1;
        }

        if (repeaterSelectedBorderColor === '') {
            repeaterSelectedBorderColor = 'rgba(0, 0, 0, 0.0)';
        }

        selectionWidth = thisWidget.getProperty('SelectionWidth', 25);
        selectionHeight = thisWidget.getProperty('SelectionHeight', 25);

        fixedMashupHeight = thisWidget.getProperty('FixedMashupHeight', 200);
        if (fixedMashupHeight === 0) {
            fixedMashupHeight = thisWidget.getProperty('MashupHeight', 200);
        }

        fixedMashupWidth = thisWidget.getProperty('FixedMashupWidth', 200);
        if (fixedMashupWidth === 0) {
            fixedMashupWidth = thisWidget.getProperty('MashupWidth', 200);
        }

        var jqElId = thisWidget.jqElementId;
        var styleBlock =
            '#' + jqElId + ' .vertical .item-selector { height: ' + fixedMashupHeight + 'px; width: ' + selectionWidth + 'px; }' +
            '#' + jqElId + ' .horizontal .item-selector-row { height: ' + selectionHeight + 'px; }' +
            '#' + jqElId + ' .horizontal .item-selector { height: ' + selectionHeight + 'px; }' +
            '#' + jqElId + ' .horizontal-wrap .item-selector-row { height: ' + selectionHeight + 'px; }' +
            '#' + jqElId + ' .horizontal-wrap .item-selector { height: ' + selectionHeight + 'px; }' +

            '#' + jqElId + ' .repeater-items { ' + repeaterBG + repeaterBorder + ' }' +
            '#' + jqElId + ' .repeater-item-unselected .item-selector-icon { background-image: url("' + repeaterUnselectedStyle.image + '"); background-repeat: no-repeat; background-position: center center; }' +
            '#' + jqElId + ' .repeater-item-selected .item-selector-icon { background-image: url("' + repeaterSelectedStyle.image + '"); background-repeat: no-repeat; background-position: center center; }' +

            '#' + jqElId + ' .vertical .item-selector { border-bottom: ' + repeaterCellBorderSize + 'px solid ' + repeaterCellBorderColor + '; }' +
            '#' + jqElId + ' .vertical .mashup-content-cell { border-bottom: ' + repeaterCellBorderSize + 'px solid ' + repeaterCellBorderColor + '; }' +

            '#' + jqElId + ' .horizontal .repeater-item { border-left: none; border-bottom: none; border-top: none; } ' +
            '#' + jqElId + ' .horizontal .item-selector { border-right: ' + repeaterCellBorderSize + 'px solid ' + repeaterCellBorderColor + '; }' +
            '#' + jqElId + ' .horizontal .mashup-content-cell { border-right: ' + repeaterCellBorderSize + 'px solid ' + repeaterCellBorderColor + '; }' +

            '#' + jqElId + ' .horizontal-wrap .mashup-content-cell { border-right: ' + repeaterCellBorderSize + 'px solid ' + repeaterCellBorderColor + '; border-bottom: ' + repeaterCellBorderSize + 'px solid ' + repeaterCellBorderColor + '; }' +
            '#' + jqElId + ' .horizontal-wrap .item-selector-wrapper { border-right: ' + repeaterCellBorderSize + 'px solid ' + repeaterCellBorderColor + '; }' +

            '#' + jqElId + ' .repeater-item-unselected .item-selector-wrapper { ' + repeaterUnselectedBG + ' }' +
            '#' + jqElId + ' .repeater-item-selected .item-selector-wrapper { ' + repeaterSelectedBG + ' }' +
            '#' + jqElId + '.allowSelection .repeater-item-selected>td>.cellposition>.selection-test-div { border: ' + repeaterSelectedBorderSize + 'px solid ' + repeaterSelectedBorderColor + '; }' +

            '#' + jqElId + '.allowSelection>.repeater-items-container>.vertical>tbody>.repeater-item-selected>td>.cellposition>.selection-test-div { bottom: -' + repeaterSelectedBorderSize + 'px; right: -' + repeaterSelectedBorderSize + 'px; top: 0; margin-left: -' + (repeaterSelectedBorderSize + selectionWidth) + 'px; margin-top: -' + repeaterSelectedBorderSize + 'px; }' +
            '#' + jqElId + '.allowSelection>.repeater-items-container>.horizontal>tbody>.repeater-row>.repeater-item-selected>.cellposition>.selection-test-div { width: ' + fixedMashupWidth + 'px; bottom: -' + repeaterSelectedBorderSize + 'px; top: -' + selectionHeight + 'px; margin-left: -' + repeaterSelectedBorderSize + 'px; margin-top: -' + repeaterSelectedBorderSize + 'px; }' +
            '#' + jqElId + '.allowSelection>.repeater-items-container>.horizontal-wrap>tbody>.repeater-row>.repeater-item-selected>.cellposition>.selection-test-div { height: ' + (fixedMashupHeight + selectionHeight) + 'px; width: ' + fixedMashupWidth + 'px; top: -' + selectionHeight + 'px; margin-left: -' + repeaterSelectedBorderSize + 'px; margin-top: -' + repeaterSelectedBorderSize + 'px; }';

        cellBorderWidth = repeaterStyle.lineThickness;
        return styleBlock;
    };

    this.afterRender = function () {
        repeaterView = thisWidget.getProperty('View');
        itemLoadBehavior = thisWidget.getProperty('ItemLoadBehavior');
        reuseMashupsSetting = thisWidget.getProperty('ReuseMashups');
        hideInnerScrollbars = thisWidget.getProperty('HideInnerScrollbars');

        if (itemLoadBehavior === undefined) {
            itemLoadBehavior = 'load-destroy-on-demand';
        }
        if (repeaterView === undefined) {
            repeaterView = 'vertical';
        }
        if( itemLoadBehavior !== 'load-destroy-on-demand') {
            reuseMashupsSetting = true;
        }
        cellsContainer = thisWidget.jqElement.find('.repeater-items-container');
        cellsContainer.css('overflow',(hideInnerScrollbars === true ? 'hidden' : 'auto'));
        allowSelection = thisWidget.getProperty('AllowSelection');

        if (allowSelection === true) {
            thisWidget.jqElement.addClass("allowSelection");
        }

        if (repeaterView === 'horizontal') {
            thisWidget.jqElement.addClass("horizontal-wrapper");
        } else if (repeaterView === 'vertical') {
            thisWidget.jqElement.addClass("vertical-wrapper");
        }

        widgetWidth = thisWidget.jqElement.width();
        widgetHeight = thisWidget.jqElement.height();
        //console.log('afterRender - updating widgetWidth and widgetHeight to ' + widgetWidth + ', ' + widgetHeight);

        fixedMashupHeight = thisWidget.getProperty('FixedMashupHeight', 200);
        if (fixedMashupHeight === 0) {
            fixedMashupHeight = thisWidget.getProperty('MashupHeight', 200);
        }

        fixedMashupWidth = thisWidget.getProperty('FixedMashupWidth', 200);
        if (fixedMashupWidth === 0) {
            fixedMashupWidth = thisWidget.getProperty('MashupWidth', 200);
        }

        thisWidget.jqElement.on('click', '.repeater-item', function (e) {
            var $item = $(e.target).closest('.repeater-item'),
                $itemRow = $item.closest('.repeater-row');

            var overflowElements = thisWidget.jqElement.find('*').filter(function(){
            	return this.style['overflow'] == 'auto';
            });
            overflowElements.css('overflow','hidden');

            if (repeaterView === 'vertical') {
                if ($item.hasClass('repeater-item-unselected')) {
                    $item.siblings('.repeater-item-selected').removeClass('repeater-item-selected').addClass('repeater-item-unselected');
                    $item.removeClass('repeater-item-unselected').addClass('repeater-item-selected');
                    if (allowSelection === true) {
                        var selectedRows = [parseInt($item.attr("row-index"), 10)];
                        thisWidget.updateSelection('Data', selectedRows);
                        e.stopPropagation();
                    }
                }
            } else if (repeaterView === 'horizontal' || repeaterView === 'horizontal-wrap') {
                var $selectorRow = $itemRow.prev();
                if ($item.hasClass('repeater-item-unselected')) {
                    cellsTableEl.find('.repeater-item-selected').removeClass('repeater-item-selected').addClass('repeater-item-unselected');
                    $selectorRow.find('.repeater-item-selected').removeClass('repeater-item-selected').addClass('repeater-item-unselected');
                    $itemRow.find('.repeater-item-selected').removeClass('repeater-item-selected').addClass('repeater-item-unselected');
                    $('#' + $item.attr('item-selector-id')).removeClass('repeater-item-unselected').addClass('repeater-item-selected');
                    $item.removeClass('repeater-item-unselected').addClass('repeater-item-selected');
                    if (allowSelection === true) {
                        var selectedRows = [parseInt($item.attr("row-index"), 10)];
                        thisWidget.updateSelection('Data', selectedRows);
                        e.stopPropagation();
                    }
                }
            }
            setTimeout(function(){
            	overflowElements.css('overflow','auto');
            },1);
        });

        thisWidget.jqElement.on('click', '.item-selector', function (e) {
            var $itemSel = $(e.target).closest('.item-selector'),
                $item,
                $itemRow;

            if (repeaterView === 'vertical') {
                $item = $itemSel.closest('.repeater-item');
                if ($item.hasClass('repeater-item-unselected')) {
                    $item.siblings('.repeater-item-selected').removeClass('repeater-item-selected').addClass('repeater-item-unselected');
                    $item.removeClass('repeater-item-unselected').addClass('repeater-item-selected');
                    if (allowSelection === true) {
                        var selectedRows = [parseInt($item.attr("row-index"), 10)];
                        thisWidget.updateSelection('Data', selectedRows);
                        e.stopPropagation();
                    }
                }
            } else if (repeaterView === 'horizontal' || repeaterView === 'horizontal-wrap') {
                $item = $('#' + $itemSel.attr('item-id'));
                $itemRow = $item.closest('.repeater-row');
                var $selectorRow = $itemSel.closest('.item-selector-row');
                if ($item.hasClass('repeater-item-unselected')) {
                    cellsTableEl.find('.repeater-item-selected').removeClass('repeater-item-selected').addClass('repeater-item-unselected');
                    $selectorRow.find('.repeater-item-selected').removeClass('repeater-item-selected').addClass('repeater-item-unselected');
                    $itemRow.find('.repeater-item-selected').removeClass('repeater-item-selected').addClass('repeater-item-unselected');
                    $itemSel.removeClass('repeater-item-unselected').addClass('repeater-item-selected');
                    $item.removeClass('repeater-item-unselected').addClass('repeater-item-selected');
                    if (allowSelection === true) {
                        var selectedRows = [parseInt($item.attr("row-index"), 10)];
                        thisWidget.updateSelection('Data', selectedRows);
                        e.stopPropagation();
                    }
                }
            }
        });

        thisWidget.jqElement.dblclick(function (e) {
            thisWidget.jqElement.triggerHandler('DoubleClicked');
            e.stopPropagation();
        });

        if (itemLoadBehavior !== 'load-all') {
            cellsContainer.on('scroll', function (e) {
                scrollId += 1;
                var timerId = scrollId;
                var updateVer = dataVer;
                if(thisWidget.scrollTimeout !== undefined){
                    clearTimeout(thisWidget.scrollTimeout);
                    thisWidget.scrollTimeout = undefined;
                }
                var setUpdateFlag = function () {
                    if (timerId === scrollId) {
                        dataVer += 1;
                        updateCells(false, false, true);
                        thisWidget.scrollTimeout = undefined;
                    }
                };
                thisWidget.scrollTimeout =  setTimeout(setUpdateFlag, 150);
            });
        }
    };

    var updateWithWaitingData = function() {
        //console.log('actually drawing again');
        cacheId = TW.uniqueId();
        dataInfotable = {
            dataShape: {
                fieldDefinitions: lastUpdatePropertyInfo.DataShape
            },
            rows: []
        };
        dataRows = lastUpdatePropertyInfo.ActualDataRows;
        nDataRows = lastUpdatePropertyInfo.ActualDataRows.length;
        //console.log('got ' + nDataRows + ' rows');
        dataVer += 1;
        loadedAllItems = false;
        initCells(true, false, true);
        newDataIsWaiting = false;

    };

    this.updateProperty = function (updatePropertyInfo) {
    	//console.log('updateProperty ' + thisWidget.jqElementId + ', updated property ' + updatePropertyInfo.TargetProperty);
        selectedRowIndices = updatePropertyInfo.SelectedRowIndices;
        //widgetWidth = thisWidget.jqElement.width();
        //widgetHeight = thisWidget.jqElement.height();
        //console.log('updateProperty - updating widgetWidth and widgetHeight to ' + widgetWidth + ', ' + widgetHeight);

        if (updatePropertyInfo.TargetProperty === 'Data') {

        	//console.log('updateProperty ' + thisWidget.jqElementId + '  called with inTimeoutWaitingToRender:' + inTimeoutWaitingToRender + ', renderQueue.length:' + renderQueue.length);

            lastUpdatePropertyInfo = updatePropertyInfo;
            // next time mashup() jq plugin should refresh the mashup definition
            if( inTimeoutWaitingToRender ) {
                // just hold on to this data - if more comes in, just overwrite it, it's fine
                newDataIsWaiting = true;
            } else {
                // go ahead and draw it
                newDataIsWaiting = false;
                updateWithWaitingData();

            }
        } else if (updatePropertyInfo.TargetProperty === 'Mashup') {
            thisWidget.setProperty('Mashup', updatePropertyInfo.SinglePropertyValue);
            dataVer += 1;
            loadedAllItems = false;
            initCells(true, false, false);
        } else if (updatePropertyInfo.TargetProperty === "CustomClass") {
            this.resize(thisWidget.jqElement.outerWidth(), thisWidget.jqElement.outerHeight());
        }
    };

    var updateSelections = function (rowIndices) {
        var $item, $itemRow, $itemSel, $itemSelRow, nSelectedRows, scrolledToSelected;
        nSelectedRows = rowIndices.length;
        scrolledToSelected = false;

        cellsTableEl.find('.repeater-item-selected').removeClass('repeater-item-selected').addClass('repeater-item-unselected');

        if (repeaterView === 'vertical') {

            for (var i = 0; i < nSelectedRows; i += 1) {
                var selRowIndex = rowIndices[i];
                var rowId = thisWidget.jqElementId + '-row-' + (selRowIndex + 1);
                $item = $('#' + rowId);
                $item.removeClass('repeater-item-unselected').addClass('repeater-item-selected');
                if (!scrolledToSelected) {
                    scrolledToSelected = true;
                    var scrollOpt = {};
                    scrollOpt.duration = 'normal';
                    scrollOpt.direction = 'vertical';
                    $item.scrollintoview(scrollOpt);
                }
                break;
            }

        } else if (repeaterView === 'horizontal' || repeaterView === 'horizontal-wrap') {

            for (var i = 0; i < nSelectedRows; i += 1) {
                var selRowIndex = rowIndices[i];
                var rowId = thisWidget.jqElementId + '-row-' + (selRowIndex + 1);
                $item = $('#mashup-content-cell-' + rowId);
                $itemRow = $item.closest('tr');
                $itemSel = $('#' + $item.attr('item-selector-id'));
                $item.removeClass('repeater-item-unselected').addClass('repeater-item-selected');
                $itemSel.removeClass('repeater-item-unselected').addClass('repeater-item-selected');
                if (!scrolledToSelected) {
                    scrolledToSelected = true;
                    var scrollOpt = {};
                    scrollOpt.duration = 'normal';
                    if (repeaterView === 'horizontal') {
                        scrollOpt.direction = 'horizontal';
                        $item.scrollintoview(scrollOpt);
                    } else {
                        scrollOpt.direction = 'vertical';
                        $itemRow.scrollintoview(scrollOpt);
                    }
                }
                break;
            }

        }
        selectedRowIndices = rowIndices;
    };

    this.handleSelectionUpdate = function (propertyName, selectedRows, selectedRowIndices) {
        updateSelections(selectedRowIndices);
    };

    this.resize = function (width, height) {
        //console.log('repeater ' + thisWidget.jqElementId + ' got resize, handleResize:' + handleResize + ', width:' + width + ', height:' + height + ', lastWidth:' + lastWidth + ', lastHeight:' + lastHeight);
        if (!handleResize) return;

        if( width === lastWidth && height === lastHeight ) {
            //console.log('no need for resize - ignoring resize');
            return;
        }

        lastWidth = width;
        lastHeight = height;

        var oldWidgetWidth = widgetWidth;
        var oldWidgetHeight = widgetHeight;
        widgetWidth = thisWidget.jqElement.width();
        widgetHeight = thisWidget.jqElement.height();
        if ((repeaterView === 'horizontal-wrap') && ((height != widgetHeight) || (width != widgetWidth) || (oldWidgetHeight != widgetHeight) || (oldWidgetWidth != widgetWidth))) {
        	//console.log('resize - directly calling initCells');
            initCells(false, true, true);
            return;
        }
        resizeId += 1;
        var timerId = resizeId;
        var updateVer = dataVer;
        var setUpdateFlag = function () {
            if (timerId === resizeId && updateVer == dataVer) {
                dataVer += 1;
              //console.log('resize calling updateCells');
                updateCells(true, true, true);
            }
        };
        setTimeout(setUpdateFlag, 50);
    };

    function clearReusableCells() {
        if(reusableCells === undefined || reusableCells === null){
            return;
        }
        for (var i = 0; i < reusableCells.length; i += 1) {
            try {
                reusableCells[i].mashup('destroy');
            } catch (err) {
            }
        }
        reusableCells = [];
    }

    this.beforeDestroy = function () {
        try {
            removeAllCells();
        }
        catch (err) {
        }
        clearReusableCells();
        reusableCells = null;
        cellCache = null;
        cellsContainer = null;
        cellsTableEl = null;
        dataInfotable = null;
        dataRows = null;
        nDataRows = null;
        cellTable = null;
        needUpdateCell = null;
        selectedRowIndices = null;
    };
};
