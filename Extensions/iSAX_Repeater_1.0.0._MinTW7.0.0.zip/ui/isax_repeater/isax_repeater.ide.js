﻿TW.IDE.Widgets.isax_repeater = function () {
    var thisWidget = this, nRendered = 0;
    var defaultItemSize = {width: 200, height: 200};

    var updateRepeaterItemSize = function(){
        var items = thisWidget.jqElement.find('.repeater-item'),
            select = thisWidget.jqElement.find('.repeater-select'),
            repeaterView = thisWidget.getProperty('View'),
            fixedMashupWidth = thisWidget.properties['FixedMashupWidth'],
            fixedMashupHeight = thisWidget.properties['FixedMashupHeight'],
            selectionWidth = thisWidget.properties['SelectionWidth'],
            selectionHeight = thisWidget.properties['SelectionHeight'];

        if (repeaterView === 'vertical') {
            items.css('height', fixedMashupHeight + 'px');
            items.css('line-height', fixedMashupHeight + 'px');
            select.css('width', selectionWidth + 'px');
        } else if (repeaterView === 'horizontal') {
            items.css('width', fixedMashupWidth + 'px');
            select.css('height', selectionHeight + 'px');
        } else if (repeaterView === 'horizontal-wrap') {
            items.css('width', fixedMashupWidth + 'px');
            items.css('height', fixedMashupHeight + 'px');
            items.css('line-height', fixedMashupHeight + 'px');
            select.css('height', selectionHeight + 'px');
        }
    };

    this.widgetProperties = function () {
        return {
            'name': "isax_" + TW.IDE.I18NController.translate('tw.repeater-ide.widget.name'),
            'description': TW.IDE.I18NController.translate('tw.repeater-ide.widget.description'),
            'category': ['Common', 'Data'],
            'defaultBindingTargetProperty': 'Data',
            'supportsAutoResize': true,
            'properties': {
                'CustomClass': {
                    'description': TW.IDE.I18NController.translate('tw.repeater-ide.properties.custom-class.description'),
                    'baseType': 'STRING',
                    'isLocalizable': false,
                    'isBindingSource': true,
                    'isBindingTarget': true,
                    'isVisible': false
                },
                'Data': {
                    'description': TW.IDE.I18NController.translate('tw.repeater-ide.widget.description'),
                    'isBindingTarget': true,
                    'isEditable': false,
                    'baseType': 'INFOTABLE',
                    'warnIfNotBoundAsTarget': true
                },
                'View': {
                    'description': TW.IDE.I18NController.translate('tw.repeater-ide.properties.view.description'),
                    'baseType': 'STRING',
                    'defaultValue': 'vertical',
                    'selectOptions': [
                        { value: 'vertical', text: TW.IDE.I18NController.translate('tw.repeater-ide.properties.view.select-options.vertical') },
                        { value: 'horizontal-wrap', text: TW.IDE.I18NController.translate('tw.repeater-ide.properties.view.select-options.horizontal-wrap') },
                        { value: 'horizontal', text: TW.IDE.I18NController.translate('tw.repeater-ide.properties.view.select-options.horizontal') }
                    ]
                },
                'FixedMashupWidth': {
                    'description': TW.IDE.I18NController.translate('tw.repeater-ide.properties.fixed-mashup-width.description'),
                    'baseType': 'NUMBER',
                    'defaultValue': 200,
                    'isVisible': false
                },
                'FixedMashupHeight': {
                    'description': TW.IDE.I18NController.translate('tw.repeater-ide.properties.fixed-mashup-height.description'),
                    'baseType': 'NUMBER',
                    'defaultValue': 200,
                    'isVisible': true
                },
                'HideInnerScrollbars': {
                    'description': TW.IDE.I18NController.translate('tw.repeater-ide.properties.hide-inner-scroll-bars.description'),
                    'baseType': 'BOOLEAN',
                    'defaultValue': false
                },
                'AllowSelection': {
                    'description': TW.IDE.I18NController.translate('tw.repeater-ide.properties.allow-selection.description'),
                    'defaultValue': false,
                    'baseType': 'BOOLEAN'
                },
                'SelectionHeight': {
                    'description': TW.IDE.I18NController.translate('tw.repeater-ide.properties.selection-height.description'),
                    'defaultValue': 25,
                    'isVisible': false,
                    'baseType': 'NUMBER'
                },
                'SelectionWidth': {
                    'description': TW.IDE.I18NController.translate('tw.repeater-ide.properties.selection-width.description'),
                    'defaultValue': 25,
                    'isVisible': false,
                    'baseType': 'NUMBER'
                },
                'AutoSelectFirstRow': {
                    'description': TW.IDE.I18NController.translate('tw.repeater-ide.properties.auto-select-first-row.description'),
                    'defaultValue': false,
                    'baseType': 'BOOLEAN'
                },
                'Mashup': {
                    'description': TW.IDE.I18NController.translate('tw.repeater-ide.properties.mashup.description'),
                    'isBindingTarget': true,
                    'defaultValue': '',
                    'baseType': 'MASHUPNAME'
                },
                'MashupParameters': {
                    'description': TW.IDE.I18NController.translate('tw.repeater-ide.properties.mashup-parameters.description'),
                    isVisible: false,
                    'baseType': 'VALUES'
                },
                'MashupWidth': {
                    'description': TW.IDE.I18NController.translate('tw.repeater-ide.properties.mashup-width.description'),
                    isVisible: false,
                    'baseType': 'NUMBER',
                    'defaultValue': 200
                },
                'MashupHeight': {
                    'description': TW.IDE.I18NController.translate('tw.repeater-ide.properties.mashup-height.description'),
                    isVisible: false,
                    'baseType': 'NUMBER',
                    'defaultValue': 200
                },
                'RepeaterStyle': {
                    'description': TW.IDE.I18NController.translate('tw.repeater-ide.properties.repeater-style.description'),
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultRepeaterStyle'
                },
                'RepeaterCellStyle': {
                    'description': TW.IDE.I18NController.translate('tw.repeater-ide.properties.repeater-cell-style.description'),
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultRepeaterCellStyle'
                },
                'RepeaterUnselectedStyle': {
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultRepeaterUnselectedStyle',
                    'description': TW.IDE.I18NController.translate('tw.repeater-ide.properties.repeater-unselected-style.description')
                },
                'RepeaterSelectedStyle': {
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultRepeaterSelectedStyle',
                    'description': TW.IDE.I18NController.translate('tw.repeater-ide.properties.repeater-selected-style.description')
                },
                'ItemLoadBehavior': {
                    'description': TW.IDE.I18NController.translate('tw.repeater-ide.properties.item-load-behavior.description'),
                    'baseType': 'STRING',
                    'defaultValue': 'load-destroy-on-demand',
                    'selectOptions': [
                        { value: 'load-destroy-on-demand', text: TW.IDE.I18NController.translate('tw.repeater-ide.properties.item-load-behavior.select-options.load-destroy-on-demand') },
                        { value: 'load-all', text: TW.IDE.I18NController.translate('tw.repeater-ide.properties.item-load-behavior.select-options.load-all') },
                        { value: 'load-on-demand', text: TW.IDE.I18NController.translate('tw.repeater-ide.properties.item-load-behavior.select-options.load-on-demand') }
                    ]
                },
                'ReuseMashups': {
                    'description': TW.IDE.I18NController.translate('tw.repeater-ide.properties.reuse-mashups.description'),
                    'baseType': 'BOOLEAN',
                    'isVisible': true
                },
                'ResponsiveLayout': {
                    'description': TW.IDE.I18NController.translate('tw.repeater-ide.properties.responsive-layout.description'),
                    'baseType': 'BOOLEAN',
                    'defaultValue': false,
                    isVisible: false
                },
                'Width': {
                    'description': TW.IDE.I18NController.translate('tw.repeater-ide.properties.width.description'),
                    'defaultValue': 400
                },
                'Height': {
                    'description': TW.IDE.I18NController.translate('tw.repeater-ide.properties.height.description'),
                    'defaultValue': 300
                }
            }
        };
    };

    this.widgetEvents = function () {
        return { 'DoubleClicked': {} };
    };

    this.renderHtml = function () {
        var html = '',
            repeaterView = thisWidget.getProperty('View');

        html += '<div class="widget-content widget-isax_repeater ' + repeaterView + '">' +
                    '<div class="repeater-items-wrapper">' +
                        '<div class="repeater-item selected"><div class="selection-test-div"></div><div class="repeater-select"><span class="repeater-select-icon"></span></div><span class="repeater-text">'+ TW.IDE.I18NController.translate('tw.repeater-ide.repeater-item') +'</span></div>' +
                        '<div class="repeater-item"><div class="repeater-select"><span class="repeater-select-icon"></span></div><span class="repeater-text">' + TW.IDE.I18NController.translate('tw.repeater-ide.repeater-item') + '</span></div>' +
                        '<div class="repeater-item"><div class="repeater-select"><span class="repeater-select-icon"></span></div><span class="repeater-text">' + TW.IDE.I18NController.translate('tw.repeater-ide.repeater-item') + '</span></div>' +
                        '<div class="repeater-item"><div class="repeater-select"><span class="repeater-select-icon"></span></div><span class="repeater-text">' + TW.IDE.I18NController.translate('tw.repeater-ide.repeater-item') + '</span></div>' +
                        '<div class="repeater-item"><div class="repeater-select"><span class="repeater-select-icon"></span></div><span class="repeater-text">' + TW.IDE.I18NController.translate('tw.repeater-ide.repeater-item') + '</span></div>' +
                    '</div>' +
                '</div>';

        return html;
    };

    this.loadMashupParameters = function (mashupName, updateSize) {
        var allWidgetProps = thisWidget.allWidgetProperties(),
            i;
        if (mashupName === undefined || mashupName.length === 0) {
            var existingParmDefs = thisWidget.properties['MashupParameters'] || [];
            // delete existing parameters from currentParameterDefs, widgetProperties and properties
            for (i = 0; i < existingParmDefs.length; i += 1) {
                delete allWidgetProps.properties[existingParmDefs[i].ParameterName];
            }

            thisWidget.properties['MashupParameters'] = [];
            thisWidget.updatedProperties();
        } else {
            $.ajax({
                url: "/Thingworx/Mashups/" + TW.encodeEntityName(mashupName) + '?Accept=application/json',
                type: "GET",
                datatype: "json",
                cache: false,
                async: false,
                error: function (xhr, status) {
                    TW.log.error('could not load mashup "' + mashupName + '"');
                },
                complete: function (xhr, status) {
                    xhr.onreadystatechange = null;
                    xhr.abort = null;
                    delete xhr.onreadystatechange;
                    delete xhr.abort;
                    xhr = null;
                },
                success: function (data) {
                    var allWidgetProps = thisWidget.allWidgetProperties();
                    var parmDefsForThisMashup = data.parameterDefinitions;
                    var existingParmDefs = thisWidget.properties['MashupParameters'] || [];
                    // delete existing parameters from currentParameterDefs, widgetProperties and properties
                    for (var i = 0; i < existingParmDefs.length; i++) {
                        delete allWidgetProps.properties[existingParmDefs[i].ParameterName];
                    }

                    thisWidget.properties['MashupParameters'] = [];

                    if (parmDefsForThisMashup !== undefined) {
                        // add the new ones in to currentParameterDefs, widgetProperties and properties
                        for (var x in parmDefsForThisMashup) {
                            parmDef = parmDefsForThisMashup[x];

                            var name = parmDef.name;
                            var description = parmDef.description;
                            var basetype = parmDef.baseType;
                            var defaultValue = parmDef.aspects.defaultValue;

                            allWidgetProps.properties[name] = {
                                'type': "property",
                                'description': description,
                                'isVisible': true,
                                'defaultValue': defaultValue,
                                'sourcePropertyName': 'Data',
                                //'baseTypeRestriction': basetype,
                                'baseType': 'FIELDNAME',
                                'showAllFieldsOption': true
                            };

                            thisWidget.properties['MashupParameters'].push(
                            {
                                ParameterName: name,
                                Description: description,
                                BaseType: basetype,
                                DefaultValue: defaultValue
                            }
                            );
                        }


                        try {
                            switch( data.aspects.mashupType )  {
                                case 'thingtemplatemashup':
                                case 'thingshapemashup':
                                    if( allWidgetProps.properties['Entity'] === undefined ) {
                                        allWidgetProps.properties['Entity'] = {
                                            'baseType': 'THINGNAME',
                                            'defaultValue': undefined,
                                            //'isBaseProperty': false,
                                            'isVisible': true,
                                            'name': 'Entity',
                                            'type': "property",
                                            'isBindingTarget': true,
                                            'isBindingSource': true
                                        };
                                        thisWidget.properties['MashupParameters'].push(
                                            {
                                                ParameterName: 'Entity',
                                                Description: 'Entity For Mashup',
                                                BaseType: 'THINGNAME',
                                                DefaultValue: undefined,
                                                ParmDef: {}
                                            }
                                        );
                                    }
                                    break;
                            }
                        } catch( err ) {}
                        thisWidget.updatedProperties();
                    }


                    try {
                        switch( data.aspects.mashupType )  {
                            case 'thingtemplatemashup':
                            case 'thingshapemashup':
                                if( allWidgetProps.properties['Entity'] === undefined ) {
                                    allWidgetProps.properties['Entity'] = {
                                        'baseType': 'THINGNAME',
                                        'defaultValue': undefined,
                                        //'isBaseProperty': false,
                                        'isVisible': true,
                                        'name': 'Entity',
                                        'type': "property",
                                        'isBindingTarget': true,
                                        'isBindingSource': true
                                    };
                                    thisWidget.properties['MashupParameters'].push(
                                        {
                                            ParameterName: 'Entity',
                                            Description: 'Entity For Mashup',
                                            BaseType: 'THINGNAME',
                                            DefaultValue: undefined,
                                            ParmDef: {}
                                        }
                                    );
                                }
                                break;
                        }
                    } catch( err ) {}

                    var items = thisWidget.jqElement.find('.repeater-text');
                    items.text(mashupName);

                    if (updateSize) {
                        try {
                            var mashupDef = JSON.parse(data.mashupContent, TW.dateReviver);

                            if (mashupDef.UI.Properties['ResponsiveLayout'] !== true) {
                                thisWidget.properties['MashupWidth'] = mashupDef.UI.Properties.Width;
                                thisWidget.properties['MashupHeight'] = mashupDef.UI.Properties.Height;
                                thisWidget.properties['FixedMashupWidth'] = mashupDef.UI.Properties.Width;
                                thisWidget.properties['FixedMashupHeight'] = mashupDef.UI.Properties.Height;
                            } else {
                                thisWidget.properties['MashupWidth'] = defaultItemSize.width;
                                thisWidget.properties['MashupHeight'] = defaultItemSize.height;
                                thisWidget.properties['FixedMashupWidth'] = defaultItemSize.width;
                                thisWidget.properties['FixedMashupHeight'] = defaultItemSize.height;
                            }

                            updateRepeaterItemSize();
                        }
                        catch (err) {
                            TW.log.error('An error occurred in TW.IDE.Widgets.repeater.loadMashupParameters()', err);
                        }
                    }
                }
            });
        }
    };

    this.afterCreate = function() {
        thisWidget.properties['ReuseMashups'] = true;
    };

    this.afterLoad = function () {
        setTimeout(function () {
            toggleFixedMashupSizeProperties(thisWidget.getProperty('View'));
            TW.IDE.updateWidgetPropertiesWindow();
            var mashupName = thisWidget.getProperty('Mashup');
            thisWidget.loadMashupParameters(mashupName);
        }, 1000);
    };

	this.afterRender = function () {
        nRendered += 1;
        var props = thisWidget.allWidgetProperties()["properties"];

        var repeaterStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('RepeaterStyle','DefaultRepeaterStyle'));
        var repeaterCellStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('RepeaterCellStyle','DefaultRepeaterCellStyle'));
        var repeaterUnselectedStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('RepeaterUnselectedStyle','DefaultRepeaterUnselectedStyle'));
        var repeaterSelectedStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('RepeaterSelectedStyle','DefaultRepeaterSelectedStyle'));

        var repeaterBG = TW.getStyleCssGradientFromStyle(repeaterStyle);
        var repeaterBorder = TW.getStyleCssBorderFromStyle(repeaterStyle);

        var repeaterUnselectedBG = TW.getStyleCssGradientFromStyle(repeaterUnselectedStyle);
        var repeaterUnselectedBorder = TW.getStyleCssBorderFromStyle(repeaterUnselectedStyle);

        var repeaterSelectedBG = TW.getStyleCssGradientFromStyle(repeaterSelectedStyle);
        var repeaterSelectedBorder = TW.getStyleCssBorderFromStyle(repeaterSelectedStyle);

        var repeaterBorderSize = repeaterStyle.lineThickness;
        var repeaterBorderColor = repeaterStyle.lineColor;

        if (repeaterBorderColor === '') {
            repeaterBorderColor = 'transparent';
        }

        if (repeaterBorderSize === '') {
            repeaterBorderColor = 0;
        }

        var repeaterCellBorderSize = repeaterCellStyle.lineThickness;
        var repeaterCellBorderColor = repeaterCellStyle.lineColor;

        if (repeaterCellBorderColor === '') {
            repeaterCellBorderColor = 'rgba(0, 0, 0, 0.0)';
        }

        var repeaterSelectedBorderSize = repeaterSelectedStyle.lineThickness;
        var repeaterSelectedBorderColor = repeaterSelectedStyle.lineColor;
        
        if (repeaterSelectedBorderSize > 1) {
            repeaterSelectedBorderSize = 1;
        }

        if (repeaterSelectedBorderColor === '') {
            repeaterSelectedBorderColor = 'rgba(0, 0, 0, 0.0)';
        }

        var SelectionWidth = thisWidget.properties['SelectionWidth'];
        var SelectionHeight = thisWidget.properties['SelectionHeight'];

        var fixedMashupHeight = thisWidget.getProperty('FixedMashupHeight', 200);
        if (fixedMashupHeight === 0) {
            fixedMashupHeight = thisWidget.getProperty('MashupHeight', 200);
        }

        var fixedMashupWidth = thisWidget.getProperty('FixedMashupWidth', 200);
        if (fixedMashupWidth === 0) {
            fixedMashupWidth = thisWidget.getProperty('MashupWidth', 200);
        }

        var jqElId = thisWidget.jqElementId;
		var styleBlock = 
			'<style>' +
                '#' + jqElId + ' .repeater-items-wrapper { ' + repeaterBG + repeaterBorder + ' }' +
                //'#' + jqElId + ' .repeater-item { ' + repeaterBG + ' }' +
                '#' + jqElId + '.horizontal .repeater-text { margin-top: ' + SelectionWidth + 'px; }' +
                '#' + jqElId + '.vertical .repeater-text { margin-left: ' + SelectionWidth + 'px; }' +

                '#' + jqElId + '.vertical .repeater-item { border-bottom: ' + repeaterCellBorderSize + 'px solid ' + repeaterCellBorderColor + '; }' +
                '#' + jqElId + '.horizontal .repeater-item { border-right: ' + repeaterCellBorderSize + 'px solid ' + repeaterCellBorderColor + '; }' +
                '#' + jqElId + '.horizontal-wrap .repeater-item { border-right: ' + repeaterCellBorderSize + 'px solid ' + repeaterCellBorderColor + '; border-bottom: ' + repeaterCellBorderSize + 'px solid ' + repeaterCellBorderColor + '; }' +
                
                '#' + jqElId + '.AllowSelection .repeater-select { ' + repeaterUnselectedBG + ' }' +
                '#' + jqElId + '.AllowSelection .repeater-select-icon { background-image: url("' + repeaterUnselectedStyle.image + '"); background-repeat: no-repeat; background-position: center center; }' +

                '#' + jqElId + '.AllowSelection .selected .repeater-select { ' + repeaterSelectedBG + ' }' +
                '#' + jqElId + '.AllowSelection .selected .repeater-select-icon { background-image: url("' + repeaterSelectedStyle.image + '"); background-repeat: no-repeat; background-position: center center; }' +
                
                '#' + jqElId + '.AllowSelection .selected .selection-test-div { border: ' + repeaterSelectedBorderSize + 'px solid ' + repeaterSelectedBorderColor + '; bottom: 0; right: 0; left: 0; top: 0; }' +

                '#' + jqElId + '.AllowSelection.vertical .selected .selection-test-div { margin-bottom: -' + repeaterSelectedBorderSize + 'px; }' +
                '#' + jqElId + '.AllowSelection.horizontal .selected .selection-test-div { margin-right: -' + repeaterSelectedBorderSize + 'px; }' +
                '#' + jqElId + '.AllowSelection.horizontal-wrap .selected .selection-test-div { margin-bottom: -' + repeaterSelectedBorderSize + 'px; margin-right: -' + repeaterSelectedBorderSize + 'px; }' +
            '</style>';
			
		$(styleBlock).prependTo(thisWidget.jqElement);

        if (thisWidget.properties['Mashup'] !== undefined && thisWidget.properties['Mashup'] !== '') {
            var items = thisWidget.jqElement.find('.repeater-text');
            items.text(thisWidget.properties['Mashup']);
            updateRepeaterItemSize();
        }

        if (thisWidget.properties['ReuseMashups'] === undefined) {
            thisWidget.properties['ReuseMashups'] = false;
        }

        toggleReuseMashupProperty(thisWidget.properties['ItemLoadBehavior']);
        toggleSelectionProperties(thisWidget.getProperty('AllowSelection'));
        if (nRendered < 2) {
            TW.IDE.updateWidgetPropertiesWindow();
        }
	};

    var toggleFixedMashupSizeProperties = function(repeaterView){
        var props = thisWidget.allWidgetProperties()["properties"],
            fixedMashupWidthProp = props['FixedMashupWidth'],
            fixedMashupHeightProp = props['FixedMashupHeight'];
        if (repeaterView == 'vertical'){
            fixedMashupWidthProp['isVisible']= false;
            fixedMashupHeightProp['isVisible']= true;
        } else if (repeaterView == 'horizontal'){
            fixedMashupWidthProp['isVisible']= true;
            fixedMashupHeightProp['isVisible']= false;
        } else if (repeaterView == 'horizontal-wrap'){
            fixedMashupWidthProp['isVisible']= true;
            fixedMashupHeightProp['isVisible']= true;
        }
    };

    var toggleReuseMashupProperty = function(loadBehavior){
        var props = thisWidget.allWidgetProperties()["properties"],
            reuseMashupProp = props['ReuseMashups'];
        reuseMashupProp['isVisible'] = (loadBehavior == 'load-destroy-on-demand');
    };

    var toggleSelectionProperties = function(allowSelection){
        var props = thisWidget.allWidgetProperties()["properties"];
        if (allowSelection) {
            if (thisWidget.getProperty('View') === 'vertical') {
                props['SelectionWidth']['isVisible']= true;
                props['SelectionHeight']['isVisible'] = false;
            } else {
                props['SelectionWidth']['isVisible'] = false;
                props['SelectionHeight']['isVisible']= true;
            }
            props['RepeaterSelectedStyle']['isVisible'] = true;
            props['RepeaterUnselectedStyle']['isVisible'] = true;
            props['AutoSelectFirstRow']['isVisible'] = true;
            thisWidget.jqElement.addClass('AllowSelection');
        } else {
            props['SelectionWidth']['isVisible'] = false;
            props['SelectionHeight']['isVisible'] = false;
            props['RepeaterSelectedStyle']['isVisible'] = false;
            props['RepeaterUnselectedStyle']['isVisible'] = false;
            props['AutoSelectFirstRow']['isVisible'] = false;
            thisWidget.jqElement.removeClass('AllowSelection');
        }
    };
	
    this.afterSetProperty = function (name, value) {
        var refreshHtml = false;
        var props = this.allWidgetProperties()["properties"];
        switch (name) {
			case 'AllowSelection':
                toggleSelectionProperties(value);
                TW.IDE.updateWidgetPropertiesWindow();
                refreshHtml = true;
                break;
			case 'RepeaterStyle':
            case 'RepeaterCellStyle':
            case 'RepeaterUnselectedStyle':
            case 'RepeaterSelectedStyle':
                refreshHtml = true;
                break;
			case 'Mashup':
                if (value === undefined || value.length === 0) {
                    var allWidgetProps = thisWidget.allWidgetProperties();
                    var existingParmDefs = thisWidget.properties['MashupParameters'] || [];
                    // delete existing parameters from currentParameterDefs, widgetProperties and properties
                    for (var i = 0; i < existingParmDefs.length; i++) {
                        delete allWidgetProps.properties[existingParmDefs[i].ParameterName];
                    }
                    thisWidget.properties['MashupParameters'] = [];
                    thisWidget.properties['MashupWidth'] = defaultItemSize.width;
                    thisWidget.properties['MashupHeight'] = defaultItemSize.height;
                    thisWidget.properties['FixedMashupWidth'] = defaultItemSize.width;
                    thisWidget.properties['FixedMashupHeight'] = defaultItemSize.height;
                    thisWidget.updatedProperties();
                    refreshHtml = true;
                } else {
                    thisWidget.loadMashupParameters(value, true);
                }
				break;
            case 'View':
                refreshHtml = true;
                toggleFixedMashupSizeProperties(value);
                TW.IDE.updateWidgetPropertiesWindow();
                break;
	        case 'FixedMashupWidth':
	        case 'FixedMashupHeight':
            case 'SelectionWidth':
            case 'SelectionHeight':
		        updateRepeaterItemSize();
		        break;
            case 'ItemLoadBehavior':
                toggleReuseMashupProperty(value);
                TW.IDE.updateWidgetPropertiesWindow();
                break;
            default:
				break;
        }
        return refreshHtml;
    };

    this.validate = function () {
        var result = [];
        var mashupNameConfigured = this.getProperty('Mashup');
        if (mashupNameConfigured === '' || mashupNameConfigured === undefined) {
            if (!this.isPropertyBoundAsTarget('Mashup')) {
                result.push({ severity: 'warning', message: TW.IDE.I18NController.translate('tw.repeater-ide.mashup-not-bound') });
            }
        }
        if (thisWidget.getProperty('View') == 'horizontal-wrap' && ((thisWidget.getProperty('FixedMashupWidth') || 0) < 1)) {
            result.push({ severity: 'warning', message: TW.IDE.I18NController.translate('tw.repeater-ide.fixed-mashup-width-warning') });
        }
        return result;
    };

    this.beforeDestroy = function () {
        thisWidget = null;
    };
};
