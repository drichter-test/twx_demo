(function ($) {
    if (TW.RuntimeDistributionbarUtilities === undefined)
        TW.RuntimeDistributionbarUtilities = new Object();


    TW.RuntimeDistributionbarUtilities.createDistributionbar = function (vertical, widget) {
        var widgetElement;
        var widgetProperties;
        var eventIds = [];

        this.runtimeProperties = function () {
            return {
                'needsError': true
            };
        };

        this.afterRender = function () {
            widgetElement = this.jqElement;
            var widget = this;
            var widgetProperties = widget.properties;

            //Validate properties
            var min = widgetProperties['Minimum'];
            if (min === undefined) {
                min = 0;
            }

            var max = widgetProperties['Maximum'];
            if (max === undefined) {
                max = 100;
            }

            var value = widgetProperties['Value'];
            if (value === undefined) {
                value = min;
            }

            var avgValue = widgetProperties['AvgValue'];
            if (avgValue === undefined) {
                avgValue = (max - min ) / 2;
            }

            var h = widgetProperties['BarHeight'];
            if (h === undefined) {
               h = 22;
            }

            var getMashupResource = function(){
                var stylesEl = $('#widget-distributionbar-styles');
                var resource = {
                    styles: {
                        append: function(rules){
                            stylesEl.append(' ' + rules);
                        },
                        clearAll: function(){
                            stylesEl.empty();
                        }
                    }
                };
                return resource;
            };

            var DistributionbarTracker = TW.getStyleFromStyleDefinition(widget.getProperty('DistributionbarTrackerStyle'));
            var DistributionbarTrackerBG = TW.getStyleCssGradientFromStyle(DistributionbarTracker);
            var DistributionbarTrackerBorder = TW.getStyleCssBorderFromStyle(DistributionbarTracker);

            var DistributionbarTrackerProgress = TW.getStyleFromStyleDefinition(widget.getProperty('DistributionbarTrackerProgressStyle'));
            var DistributionbarTrackerProgressBG = TW.getStyleCssGradientFromStyle(DistributionbarTrackerProgress);
            var DistributionbarTrackerProgressBorder = TW.getStyleCssBorderFromStyle(DistributionbarTrackerProgress);

            var resource = getMashupResource();
            var widgetHeight = 'height: ' + h + 'px;';
            var widgetStyles =
                '#' + widget.jqElementId + ' .widget-distributionbar-rightZone { '+ DistributionbarTrackerProgressBG + DistributionbarTrackerProgressBorder +' } ' +
                '#' + widget.jqElementId + ' .widget-distributionbar-controls { '+ DistributionbarTrackerBG + DistributionbarTrackerBorder + ' ' +  widgetHeight + ' } ';
            resource.styles.append(widgetStyles);

        };

        this.updateProperty = function (updatePropertyInfo) {
            var calRatio = function (min, max, val) {
                var ratio = 100 / (max - min);
                return (val - min) * ratio;
            };

            var min = this.getProperty('Minimum');
            var max = this.getProperty('Maximum');
            var val = this.getProperty('Value');
            var avgVal = this.getProperty('AvgValue');

            var rawValue = updatePropertyInfo.RawSinglePropertyValue;
            switch (updatePropertyInfo.TargetProperty) {
                case 'Value':
                    if (val !== rawValue) {
                        val = rawValue;
                        if( isNaN(val) ) { val = 0; }
                        this.setProperty('Value', rawValue);
                    }
                    break;
                case 'Minimum':
                    min = rawValue;
                    if( isNaN(min) ) { min = 0; }
                    this.setProperty('Minimum', min);
                    break;
                case 'Maximum':
                    max = rawValue;
                    if( isNaN(max) ) { max = 0; }
                    this.setProperty('Maximum', max);
                    break;
                case 'AvgValue':
                    avgValue = rawValue;
                    if( isNaN(avgValue) ) { avgVal = -1; }
                    this.setProperty('AvgValue', rawValue);
                    break;
            }
            widgetElement.find('.widget-distributionbar-rightZone').width('' + calRatio(min, max, val) + "%");
            if (avgValue < 0) {
                widgetElement.find('.widget-distributionbar-avg').hide();
            } else {
                widgetElement.find('.widget-distributionbar-avg').show();
                widgetElement.find('.widget-distributionbar-avg').css('left', calRatio(min, max, avgValue) + "%");
            }
        };

        return this;
    };

    TW.Runtime.Widgets.distributionbar = function () {
        var bar = new TW.RuntimeDistributionbarUtilities.createDistributionbar(false, this);

        this.runtimeProperties = bar.runtimeProperties;

        this.calRatio = function (type) {
            var min = this.getProperty('Minimum') || 0;
            var val = this.getProperty(type);
            if (!type || isNaN(val)) {
                return min;
            }
            var min = this.getProperty('Minimum') || 0;
            var max = this.getProperty('Maximum') || 100;
            var ratio = 100 / (max - min);

            return (val - min) * ratio;
        }


        this.renderHtml = function () {
            var barStyle = TW.getStyleFromStyleDefinition(this.getProperty('DistributionbarBGStyle'));
            var barBG = 'style=" ' + TW.getStyleCssGradientFromStyle(barStyle) + '"';

            var html = '<style id="widget-distributionbar-styles"></style>';

            html += '<div class="widget-content widget-distributionbar">'
                + '<div class="widget-distributionbar-controls">'
                + '<div class="widget-distributionbar-rightZone" style="width:' + this.calRatio('Value') + '%"></div>';

            var avgVal = this.getProperty('AvgValue');
            if (avgVal >= 0) {
                html += '<div class="widget-distributionbar-avg" style="left:' + this.calRatio('AvgValue') + '%"></div>';
            }else{
                html += '<div class="widget-distributionbar-avg" style="display: none;"></div>'
            }

            html += '</div></div>';

            return html;
        };


        this.afterRender = bar.afterRender;
        this.updateProperty = bar.updateProperty;

        this.beforeDestroy = function () {
        };

    };

})(jQuery);
