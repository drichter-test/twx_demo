﻿TW.Runtime.Widgets.isax_panel = function () {
    var hideScrollbars;

    this.runtimeProperties = function () {
        return {
			'borderWidth': 0,
            'isContainer': true,
	        'supportsAutoResize': true
		};
    };

    this.renderHtml = function () {
        var formatResult = TW.getStyleFromStyleDefinition(this.getProperty('Style', 'DefaultPanelStyle'));
		var cssPanelBackground = TW.getStyleCssGradientFromStyle(formatResult);
		var cssPanelBorder = TW.getStyleCssBorderFromStyle(formatResult);

	    var positioningCss = '';

        var html = '';
        html +=
        '<div class="widget-isax_panel widget-container widget-content ' + Encoder.htmlEncode(this.getProperty('ContainerClass','')) + '" style="' + ((formatResult.image !== undefined && formatResult.image.length > 0) ? 'background-color: ' + formatResult.backgroundColor + '; background-image: url(' + formatResult.image + '); background-image: url(' + formatResult.image + '), -moz-linear-gradient(top,  ' + formatResult.backgroundColor + ',  ' + formatResult.secondaryBackgroundColor + '); background-image: url(' + formatResult.image + '), -webkit-gradient(linear, left top, left bottom, from(' + formatResult.backgroundColor + '), to(' + formatResult.secondaryBackgroundColor + ')); background-image: url(' + formatResult.image + '), -webkit-linear-gradient(top, ' + formatResult.backgroundColor + ', ' + formatResult.secondaryBackgroundColor + '); background-repeat: no-repeat; background-position: center center;' : '') + ' background-image: url(' + formatResult.image + '), -ms-linear-gradient(top, ' + formatResult.backgroundColor + ', ' + formatResult.secondaryBackgroundColor + '); border-radius: ' + this.getProperty('CornerRadius') + 'px;">';
        + '</div>';
        return html;
    };

    this.renderStyles = function(){
        var thisWidget = this;
        var DefaultPanel = TW.getStyleFromStyleDefinition(this.getProperty('Style', 'DefaultPanelStyle'));
        var DefaultPanelBG = TW.getStyleCssGradientFromStyle(DefaultPanel);
        var DefaultPanelBorder = TW.getStyleCssBorderFromStyle(DefaultPanel);

        var styleBlock = '#' + thisWidget.jqElementId + ' { '+ DefaultPanelBG + DefaultPanelBorder +' } ';

        return styleBlock;
    };

    this.initCSSClassforBoundingBox = function(elemId,prop,val) {
        var elem = $('.'+elemId+'wbb');
        var styleCode = '.'+elemId+'wbb{';
        styleCode += 'top:'+(prop==='top'? val : thisWidget.getProperty('Top')+"px")+";";
        styleCode += 'left:'+(prop==='left'? val : thisWidget.getProperty('Left')+"px")+";";
        styleCode += 'width:'+(prop==='width'? val : thisWidget.getProperty('width')+"px")+";";
        styleCode += 'height:'+(prop==='height'? val : thisWidget.getProperty('height')+"px")+";";
        return styleCode;
    };

	this.afterRender = function() {

        var thisWidget = this;
        hideScrollbars = thisWidget.getProperty('HideScrollbars');

	    var hAnchor = this.getProperty('HorizontalAnchor');
	    if( hAnchor === undefined ) {
		    hAnchor = 'left';
	    }
	    var vAnchor = this.getProperty('VerticalAnchor');
	    if( vAnchor === undefined ) {
		    vAnchor = 'top';
	    }

		if( $('#runtime-workspace').hasClass('print') )  {
			this.jqElement.closest('.widget-container-widget').addClass('panelinside');
		}
		/*if( $('#runtime-workspace').hasClass('responsive') )  {
			this.jqElement.closest('.widget-bounding-box').css("overflow","auto");
		}*/
        var positioningCss = '';

        var boundingBox = this.jqElement.closest('.widget-bounding-box');

        switch( hAnchor ) {
            case 'center':
                var width = this.getProperty('Width');
                if (this.hasCustomClass) {
                    var tempStyle = this.initCSSClassforBoundingBox(thisWidget.jqElementId,'left','50%');
                    tempStyle += 'margin-left: calc(-width/2) px;}';
                    document.styleSheets[0].insertRule(tempStyle,
                        document.styleSheets[0].cssRules.length);
                } else {
                    boundingBox.css({'margin-left': '-' + (width/2) + 'px', 'left':'50%'});
                }
                break;
            }

        switch( vAnchor ) {
            case 'middle':
                var height = this.getProperty('Height');
                if (this.hasCustomClass) {
                    var tempStyle = this.initCSSClassforBoundingBox(thisWidget.jqElementId,'top','50%');
                    tempStyle += 'margin-left: calc(-height/2) px;}';
                    document.styleSheets[0].insertRule(tempStyle,
                            document.styleSheets[0].cssRules.length);
                } else {
                    boundingBox.css({'margin-top': '-' + (height/2) + 'px', 'top':'50%'});
                }
                break;
        }

        setTimeout(function() {
            if( thisWidget.jqElement !== undefined )  {
                  thisWidget.jqElement.css("overflow", (hideScrollbars === true ? 'hidden' : 'auto'));
            }
        }, 1);

    };

    this.updateProperty = function (updatePropertyInfo) {
        if (updatePropertyInfo.TargetProperty === 'ContainerClass')
        {
            this.jqElement.removeClass(this.properties.ContainerClass);
            this.jqElement.addClass(updatePropertyInfo.SinglePropertyValue);
            this.setProperty('ContainerClass',updatePropertyInfo.SinglePropertyValue);
        }
    };
};
