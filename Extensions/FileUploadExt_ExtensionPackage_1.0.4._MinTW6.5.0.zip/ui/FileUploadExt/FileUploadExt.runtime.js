﻿TW.Runtime.Widgets.fileuploadext = function () {

    var _uuid;
    var displayRepositorySelector;
    var displayPathTextBox;
    var widgetReference = this;

	
	var formatFileUploadExtResult;
	var formatRepositoryResult;
	var formatFocusResult;

	var cssFocusStyle;
		
	var cssFileUploadExtBackground ;
	var cssFileRepositoryText;
	var cssFileUploadExtBorder;
	var cssRepositoryBackground;

    this.runtimeProperties = function () {
        return {
            'needsDataLoadingAndError': true,
            'borderWidth': 1
        };
    };

    this.renderHtml = function () {
        var html = '';

        formatFileUploadExtResult = TW.getStyleFromStyleDefinition(this.getProperty('Style', 'DefaultFileUploadStyle'));
        formatRepositoryResult = TW.getStyleFromStyleDefinition(this.getProperty('RepositoryStyle', 'DefaultRepositoryStyle'));
        formatFocusResult = TW.getStyleFromStyleDefinition(this.getProperty('FocusStyle','DefaultButtonFocusStyle'));

        cssFocusStyle = TW.getStyleCssBorderFromStyle(formatFocusResult);
        cssFocusStyle += 'margin: -'+cssFocusStyle.match(/border-width:([0-9]+px;)/)[1];

        cssFileUploadExtBackground = TW.getStyleCssGradientFromStyle(formatFileUploadExtResult);
        cssFileRepositoryText = TW.getStyleCssTextualNoBackgroundFromStyle(formatRepositoryResult);
        cssFileUploadExtBorder = TW.getStyleCssBorderFromStyle(formatFileUploadExtResult);
        cssRepositoryBackground = TW.getStyleCssGradientFromStyle(formatRepositoryResult);

        html += '<div class="widget-content widget-fileuploadext" style="'+ cssFileUploadExtBackground + cssFileUploadExtBorder +'">';
        html += '</div>';

        return html;
    };
    
    this.serviceInvoked = function (serviceName) {
        if (serviceName === 'StartUpload') {
            try{
                this.jqElement.find('#' + getSubmitButtonName()).click();
            }
            catch (e)
            {
                console.log('validator widget, failed to click Upload Button: '+e);
            }
        } else {
            console.log('validator widget, unexpected serviceName invoked "' + serviceName + '"');
        };
    };

    this.afterRender = function () {
        var widgetElement = this.jqElement;

        displayRepositorySelector = widgetReference.getProperty('DisplayRepositorySelector');
        displayPathTextBox = widgetReference.getProperty('DisplayPathTextBox');

        //The form and input type of file need a name and id, therefore, generate it here (the names need to be unique in case there are multiple widgets)
        _uuid = getRandomUUID();

        widgetElement.append(getFormHTML());
        var formElement = widgetElement.find('#' + getFormName());
        formElement.append(getFormContentsHTML());

        $(getStyles()).prependTo(formElement);

        $(widgetElement).on('focusin', function () {
            $(widgetElement).addClass('focus');
        });

        $(widgetElement).on('focusout', function (e) {
            $(widgetElement).removeClass('focus');
        });

        formElement.ajaxForm({
            headers: { "X-XSRF-TOKEN": "TWX-XSRF-TOKEN-VALUE" },
            success: function (response, status, xhr, x) {
                widgetReference.jqElement.triggerHandler('UploadComplete');
            },
            error:function(jqXHR, textStatus, errorThrown) {
                TW.log.error('FileUpload Failed: "' + textStatus + '"');
                widgetReference.jqElement.triggerHandler('UploadFailed');
            }
        });

	    var selectorElement = widgetElement.find('#' + getFileRepositoryName());
	    var pathElement = widgetElement.find('#' + getPathName());
	    var inputFilesNameElement = widgetElement.find('#' + getInputFilesName());
	    var submitButtonElement = widgetElement.find('#' + getSubmitButtonName());
	    submitButtonElement.click(function(e) {
            console.log('FileUpload Started');
            widgetReference.jqElement.triggerHandler('UploadStart');
	    });
        var displayUploadButton = widgetReference.getProperty('DisplayUploadButton');
		if(displayUploadButton === false){
			submitButtonElement.hide();
            inputFilesNameElement.attr('style','width: 290px');
        }

	    if(selectorElement !== undefined) {
	    	var fileRepoName = widgetReference.getProperty("RepositoryName");
	    	if(fileRepoName != undefined && fileRepoName != '')
	    		selectorElement.val(fileRepoName);
	    }
	    
	    selectorElement.change(function(e) {
            widgetReference.setProperty('RepositoryName', selectorElement.val());
	    });
	    pathElement.change(function(e) {
            widgetReference.setProperty('Path', pathElement.val());
            
            var path = widgetReference.getProperty('Path');
            var filename = widgetReference.getProperty('FileName');
            
            nIndexSlash = path.lastIndexOf('/');
		    
		    var fullpath;
		    
		    if( nIndexSlash >= 0 && nIndexSlash == path.length) {
			    fullpath = path + filename;
		    }
		    else {
			    fullpath = path + "/" + filename;
		    }
		    
            widgetReference.setProperty('FullPath', fullpath);
	    });
	    inputFilesNameElement.change(function(e) {
		    var filename = inputFilesNameElement.val();
		    nIndexSlash = filename.lastIndexOf('\\');
		    if( nIndexSlash >= 0 ) {
			    filename = filename.substring(nIndexSlash+1);
		    }
            widgetReference.setProperty('FileName', filename);
            
            var path = widgetReference.getProperty('Path');
            var filename = widgetReference.getProperty('FileName');
            
            nIndexSlash = path.lastIndexOf('/');
		    
		    var fullpath;
		    
		    if( nIndexSlash >= 0 && nIndexSlash == path.length) {
			    fullpath = path + filename;
		    }
		    else {
			    fullpath = path + "/" + filename;
		    }
		    
            widgetReference.setProperty('FullPath', fullpath);
	    });

		if(displayRepositorySelector === false && displayPathTextBox === false) {
			this.jqElement.find('.repository-info').attr('style','padding:0px; border-bottom: none;');
		}

		if(displayRepositorySelector === false){
			this.jqElement.find('.fileuploadext-path').addClass('noRepository');
		}
		if(displayPathTextBox === false){
			this.jqElement.find('.fileuploadext-repository').addClass('noPath');
		}
    };

    this.updateProperty = function (updatePropertyInfo) {
        //var domElementId = this.jqElementId;
        var widgetElement = this.jqElement;
        //var widgetProperties = this.properties;

        switch (updatePropertyInfo.TargetProperty) {
            case 'RepositoryName':
                if (displayRepositorySelector == true) {
                    var selectElement = widgetElement.find('div.fileuploadext-repository select');
                    selectElement.val(updatePropertyInfo.SinglePropertyValue);
	                widgetReference.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.SinglePropertyValue);
                } else {
                    var repoNameElement = widgetElement.find('div.fileuploadext-hidden-repository input');
                    repoNameElement.val(updatePropertyInfo.SinglePropertyValue);
	                widgetReference.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.SinglePropertyValue);
                }
                break;
            case 'Path':
                if (displayPathTextBox == true) {
                    var pathElement = widgetElement.find('div.fileuploadext-path input');
                    pathElement.val(updatePropertyInfo.SinglePropertyValue);
	                widgetReference.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.SinglePropertyValue);
                } else {
                    var pathElement = widgetElement.find('div.fileuploadext-hidden-path input');
                    pathElement.val(updatePropertyInfo.SinglePropertyValue);
	                widgetReference.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.SinglePropertyValue);
                }
                break;
            default:
                break;
        }

        widgetElement = null;
    };

    this.afterSetProperty = function (name, value) {
        var refreshHtml = false;
        switch (name) {
            case 'Style':
                refreshHtml = true;
                break;
            default:
                break;
        }
        return refreshHtml;
    };

    this.beforeDestroy = function () {
        widgetReference = null;
    };

    //
    //  Returns the list of file repository things
    //
    var getFileRepositoryList = function () {
        var repositoryList;

        //Get the current user
        var invoker = new ThingworxInvoker({
            entityType: 'Resources',
            entityName: 'SearchFunctions',
            characteristic: 'Services',
            target: 'SearchThingsByTemplate',
            apiMethod: 'post',
            parameters: {
                'thingTemplate': 'FileRepository'
            }
        });

        var successHandler = function (result) {
            repositoryList = result.rows;
        };

        var failHandler = function (response) {
            TW.log.error('Failed to get file repository list');
        };

        invoker.invokeService(
            function (invoker) {
                successHandler(invoker.result);
            },
            function (invoker, xhr) {
                failHandler(xhr.responseText);
            },
            false
        );

        return repositoryList;
    };

    var getFormName = function () {
        return 'upload-form-' + _uuid;
    };

    var getInputFilesName = function () {
        return 'upload-files-' + _uuid;
    };

    var getSubmitButtonName = function () {
        return 'upload-submit-' + _uuid;
    };

    var getFileRepositoryName = function () {
        return 'upload-repository-' + _uuid;
    };

    var getPathName = function () {
        return 'upload-path-' + _uuid;
    };

    var getStyles = function(){
    	var styleBlock = '<style>' +
    		'#' + widgetReference.jqElementId + '.focus form { ' + cssFocusStyle + ' } ' +
		'</style>';
    	return styleBlock;
    };

    var getFormHTML = function () {
        var html = '';
        html += '<form name="' + getFormName() + '" id="' + getFormName() + '" class="fileuploadext-form" enctype="multipart/form-data" method="POST" action="/Thingworx/FileRepositoryUploader">' +
        		'</form>';
        return html;
    };

    var getFormContentsHTML = function () {
        var html = '';

        html += '<div class="repository-info clearfix" style="'+ cssRepositoryBackground +'">' + getFileRepositoryHTML() + getPathHTML() + '</div>';
        html += '<div class="file-browser">' + 
					getInputFilesHTML() +
					getSubmitButtonHTML() +
				'</div>';
				

			
        return html;
    };

    var getFileRepositoryHTML = function () {
        var html = '';
        if (displayRepositorySelector == true) {
            var repositoryList = getFileRepositoryList();
            html += '<div class="fileuploadext-repository ">' + 
						'<label style="'+ cssFileRepositoryText +'">' + TW.Runtime.convertLocalizableString('[[fileRepository]]') + ':</label>';
			html += '<select class="repository-name" tabindex="' + widgetReference.getProperty('TabSequence') + '" name="' + getFileRepositoryName() + '" id="' + getFileRepositoryName() + '" >'; 
           	for (var count = 0; count < repositoryList.length; count++) {
               var repositoryName = repositoryList[count].name;
               html += '<option value="' + repositoryName + '">' + repositoryName + '</option>';
           	}
            html += '</select></div>';
        } else {
            html += '<div class="fileuploadext-hidden-repository" style="display:none;">' + 
						'<input tabindex="' + widgetReference.getProperty('TabSequence') + '" name="' + getFileRepositoryName() + '" id="' + getFileRepositoryName() + '" value="' + widgetReference.getProperty("RepositoryName") + '">' +
					'</div>';
        }

        return html;
    };

    var getPathHTML = function () {
        var html = '';
        if (displayPathTextBox == true) {
            html += '<div class="fileuploadext-path">' + 
							'<label style="'+ cssFileRepositoryText +'">' + TW.Runtime.convertLocalizableString('[[pathOnRepository]]') + ':</label>' +
							'<input class="upload-input" tabindex="' + widgetReference.getProperty('TabSequence') + '" type="text" name="' + getPathName() + '" id="' + getPathName() + '" value="' + widgetReference.getProperty("Path")  + '"></input>' +
            		'</div>';
        } else {
            html += '<div class="fileuploadext-hidden-path" style="display:none;">' + 
						'<input type="hidden" name="' + getPathName() + '" id="' + getPathName() + '" value="' + widgetReference.getProperty("Path")  + '"></input>' + 
            		'</div>';
        }
        return html;
    };

    var getInputFilesHTML = function () {
        var html = '';
        html += '<input tabindex="' + widgetReference.getProperty('TabSequence') + '" name="' + getInputFilesName() + '" id="' + getInputFilesName() + '" type="file" font-size="2" class="fileuploadext-file-input" size="18"></input>';
        return html;
    };

    var getSubmitButtonHTML = function () {
        var html = '';
        html += '<input tabindex="' + widgetReference.getProperty('TabSequence') + '" name="' + getSubmitButtonName() + '" id="' + getSubmitButtonName() + '" type="submit" class="fileuploadext-submit-button" value="' + TW.Runtime.convertLocalizableString('[[upload]]') + '"></input>';
        return html;
    };

};