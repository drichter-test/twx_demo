﻿TW.IDE.Widgets.fileuploadext = function () {
	
	var defaultHeight = 95;
	var noOptionHeight = 40;
    var defaultWidth = 302;
    var noUploadButtonWidth = 200;
	

    this.widgetProperties = function () {
	
		
        return {
            'name': 'File Upload Extended',
            'description': 'Uploads a file from a client machine to a File Repository',
            'category': ['Data'],
            'borderWidth': 1,
            'properties': {
                'Width': {
                    'defaultValue': defaultWidth,
					'isEditable': false
                },
                'Height': {
                    'defaultValue': defaultHeight,
					'isEditable': false
                },
                'TabSequence': {
                    'description': 'Tab sequence index',
                    'baseType': 'NUMBER',
                    'defaultValue': 0
                },
                'DisplayUploadButton': {
                    'baseType': 'BOOLEAN',
                    'defaultValue': true
                },
                'RepositoryName': {
                    'description': 'The name of the File Repository used by the widget',
                    'isBindingTarget': true,
                    'isBindingSource': true,
                    'defaultValue': 'SystemRepository',
                    'baseType': 'THINGNAME',
                    'mustImplement':
                    { 
                        'EntityType': 'ThingTemplates',
                        'EntityName': 'FileRepository'
                    }
                },
                'DisplayRepositorySelector': {
                    'baseType': 'BOOLEAN',
                    'defaultValue': true
                },
                'Path': {
                    'description': 'The path on the File Repository used by the widget',
                    'isBindingTarget': true,
                    'isBindingSource': true,
                    'defaultValue': '/',
                    'baseType': 'STRING'
                },
                'DisplayPathTextBox': {
                    'baseType': 'BOOLEAN',
                    'defaultValue': true
                },
                'FileName': {
                    'description': 'The filename the user selected',
                    'isBindingSource': true,
                    'defaultValue': '',
                    'baseType': 'STRING'
                },
                'FullPath': {
                    'description': 'The full path on the repository',
                    'isBindingSource': true,
                    'defaultValue': '',
                    'baseType': 'STRING'
                },
				'Style':{
                    'baseType': 'STYLEDEFINITION',
					'defaultValue': 'DefaultFileUploadStyle'
				},
                'FocusStyle': {
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultButtonFocusStyle'
                },
				'RepositoryStyle':{
                    'baseType': 'STYLEDEFINITION',
					'defaultValue': 'DefaultRepositoryStyle'
				}
            },
			'isResizeable': false
        };
    };

    this.widgetEvents = function () {
        return {
            'UploadStart': { 'warnIfNotBound': false },
            'UploadComplete': { 'warnIfNotBound': false },
            'UploadFailed': { 'warnIfNotBound': false }
        };
    };

    this.widgetServices = function () {
        return {
            'StartUpload': { 'warnIfNotBound': true }
        };
    };

    this.renderHtml = function () {
		
		
		var formatFileUploadExtResult = TW.getStyleFromStyleDefinition(this.getProperty('Style'));
		var formatRepositoryResult = TW.getStyleFromStyleDefinition(this.getProperty('RepositoryStyle'));

		var cssFileUploadExtBackground = TW.getStyleCssGradientFromStyle(formatFileUploadExtResult);
		var cssFileRepositoryText = TW.getStyleCssTextualNoBackgroundFromStyle(formatRepositoryResult);
		var cssFileUploadExtBorder = TW.getStyleCssBorderFromStyle(formatFileUploadExtResult);
		var cssRepositoryBackground = TW.getStyleCssGradientFromStyle(formatRepositoryResult);
		
		
		if(this.getProperty('DisplayUploadButton') === undefined){
			this.setProperty('DisplayUploadButton', true);
		}
		if(this.getProperty('DisplayRepositorySelector') === undefined){
			this.setProperty('DisplayRepositorySelector', true);
		}
		if(this.getProperty('DisplayPathTextBox') === undefined){
			this.setProperty('DisplayPathTextBox', true);
		}
		
        var displayUploadButton = this.getProperty('DisplayUploadButton');
        var displayRepositorySelector = this.getProperty('DisplayRepositorySelector');
        var displayPathTextBox = this.getProperty('DisplayPathTextBox');

        var html = '';
        html += '<div class="widget-content widget-fileuploadext widget-fileuploadext-container" style="'+ cssFileUploadExtBackground + cssFileUploadExtBorder +'">' + 
					'<div class="repository-info clearfix" style="'+ cssRepositoryBackground +'">';
					
        	if (displayRepositorySelector == true) {
	            html += '<div class="fileuploadext-repository" >' + 
							'<label style="'+ cssFileRepositoryText +'">File Repository:</label>' + 
							'<div class="repository-name"><span>SystemRepository</span></div>' +
						'</div>';
	        }
	        if (displayPathTextBox == true) {
	            html += '<div class="fileuploadext-path">' +
	            			'<label style="'+ cssFileRepositoryText +'">Path on Repository:</label>' + 
							'<div class="upload-input"></div>' + 
						'</div>';
	        }
			html += '</div>' ;
            html += '<div class="file-browser">' + 
                        '<div class="fileuploadext-browse" />';
	        if (displayUploadButton == true) {
                html += '<div class="fileuploadext-submit-button"><span>Upload</span></div>';
            }

			html += '</div></div>';

        return html;
    };
	
	this.afterRender = function () {
		if(this.getProperty('DisplayRepositorySelector') === false && this.getProperty('DisplayPathTextBox') === false) {
			this.jqElement.find('.repository-info').attr('style','padding:0px; border-bottom: none;');
		}
		
		if(this.getProperty('DisplayRepositorySelector') === false){
			this.jqElement.find('.fileuploadext-path').addClass('noRepository');
		}
		if(this.getProperty('DisplayPathTextBox') === false){
			this.jqElement.find('.fileuploadext-repository').addClass('noPath');
		}
    };

    this.afterSetProperty = function (name, value) {
        var result = false;
        switch (name) {
            case 'Style':
			case 'RepositoryStyle':
            case 'DisplayUploadButton':
            case 'DisplayRepositorySelector':
            case 'DisplayPathTextBox':
                if(name == "DisplayUploadButton") {
                    if (value == true)
                        this.setProperty('Width', defaultWidth);
                    else
                        this.setProperty('Width', noUploadButtonWidth);
				} else if(this.getProperty('DisplayRepositorySelector') === false && this.getProperty('DisplayPathTextBox') === false) {
					this.setProperty('Height', noOptionHeight);
				} else if(this.getProperty('DisplayRepositorySelector') === true || this.getProperty('DisplayPathTextBox') === true) {
					this.setProperty('Height', defaultHeight);
				}
                result = true;
                break;
            default:
                break;
        }
        return result;

    };
};