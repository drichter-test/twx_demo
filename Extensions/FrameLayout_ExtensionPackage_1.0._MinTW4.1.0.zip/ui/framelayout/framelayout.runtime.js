﻿TW.Runtime.Widgets.framelayout = function () {

    this.runtimeProperties = function () {
        return {
			'borderWidth': 0,
            'isContainer': true,
	        'supportsAutoResize': true,
                'isContainerWithDeclarativeSpotsForSubWidgets': true
		};
    };

    this.renderHtml = function () {
        var formatResult = TW.getStyleFromStyleDefinition(this.getProperty('Style', 'DefaultPanelStyle'));
		var cssPanelBackground = TW.getStyleCssGradientFromStyle(formatResult);
		var cssPanelBorder = TW.getStyleCssBorderFromStyle(formatResult);

	    var positioningCss = '';

//	    var hAnchor = this.getProperty('HorizontalAnchor');
//	    if( hAnchor === undefined ) {
//		    hAnchor = 'left';
//	    }
//	    var vAnchor = this.getProperty('VerticalAnchor');
//	    if( vAnchor === undefined ) {
//		    vAnchor = 'top';
//	    }
//
//	    switch( hAnchor ) {
//		    case 'center':
//			    positioningCss += 'margin-left: auto;margin-right: auto;';
//			    break;
//	    }
//
//	    switch( vAnchor ) {
//		    case 'middle':
//			    positioningCss += 'margin-top: auto;margin-bottom: auto;';
//			    break;
//	    }

        var html = '';
        html +=
        '<div class="widget-panel widget-container widget-content" style="' + ((formatResult.image !== undefined && formatResult.image.length > 0) ? 'background-color: ' + formatResult.backgroundColor + '; background-image: url(' + formatResult.image + '); background-image: url(' + formatResult.image + '), -moz-linear-gradient(top,  ' + formatResult.backgroundColor + ',  ' + formatResult.secondaryBackgroundColor + '); background-image: url(' + formatResult.image + '), -webkit-gradient(linear, left top, left bottom, from(' + formatResult.backgroundColor + '), to(' + formatResult.secondaryBackgroundColor + ')); background-image: url(' + formatResult.image + '), -webkit-linear-gradient(top, ' + formatResult.backgroundColor + ', ' + formatResult.secondaryBackgroundColor + '); background-repeat: no-repeat; background-position: center center;' : '') + ' background-image: url(' + formatResult.image + '), -ms-linear-gradient(top, ' + formatResult.backgroundColor + ', ' + formatResult.secondaryBackgroundColor + ');">' + 
			'<div style="width: 100%; height: 100%; position: absolute;" sub-widget-container-id="' + this.properties.Id + '"  sub-widget="1"></div>' +
			'<div style="width: 100%; height: 100%; position: absolute;" sub-widget-container-id="' + this.properties.Id + '"  sub-widget="2"></div>';
        + '</div>';
        return html;
    };

	this.afterRender = function() {
		
		
		var jqElement = this.jqElement;
			
			
		
		var thisWidget = this;
		var DefaultPanel = TW.getStyleFromStyleDefinition(this.getProperty('Style', 'DefaultPanelStyle'));
		var DefaultPanelBG = TW.getStyleCssGradientFromStyle(DefaultPanel);
		var DefaultPanelBorder = TW.getStyleCssBorderFromStyle(DefaultPanel);
		
		var styleBlock =
			'<style>' +	
				'#' + thisWidget.jqElementId + ' { '+ DefaultPanelBG + DefaultPanelBorder +' } ' +
			'</style>';

		$(styleBlock).prependTo(thisWidget.jqElement);
		
		if( $('#runtime-workspace').hasClass('print') )  {
			this.jqElement.closest('.widget-container-widget').addClass('panelinside');
		}
		/*if( $('#runtime-workspace').hasClass('responsive') )  {
			this.jqElement.closest('.widget-bounding-box').css("overflow","auto");
		}*/
	    var positioningCss = '';

		var boundingBox = this.jqElement.closest('.widget-bounding-box');

	    setTimeout(function() {
	    	thisWidget.jqElement.css("overflow", "auto");
     	}, 1);

	};
};

