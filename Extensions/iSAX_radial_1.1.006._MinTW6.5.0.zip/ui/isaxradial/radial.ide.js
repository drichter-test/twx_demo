TW.IDE.Widgets.isaxradial = function () {

  this.widgetProperties = function () {
    return {
      name: "iSAX_Radial",
      description: "radial percentage graph",
      category: ['Common'],
      defaultBindingTargetProperty: 'value',
      supportsAutoResize: true,
      properties: {
        value: {
          baseType: "NUMBER",
          defaultValue: 62,
          isBindingTarget: true,
          isBindingSource: true,
          isVisible: true,
          isEditable: true,
          warnIfNotBoundAsSource: true,
          warnIfNotBoundAsTarget: true
        },
        label: {
          baseType: "STRING",
          defaultValue: "",
          isVisible: true,
          isEditable: true,
          isBindingSource: true,
          isBindingTarget: true,
          description: 'Text that is displayed beneath graph',
        },
        backgroundColor: {
          baseType: "STRING",
          defaultValue: "rgba(255,255,255,1)",
          isVisible: true,
          isEditable: true,
          description: 'Any valid CSS-Color can be entered, use rgba() to use transparency',
        },
        radialcolor_active: {
          baseType: "STRING",
          defaultValue: "rgba(76, 141, 254, 1)",
          isVisible: true,
          isEditable: true,
          description: 'Any valid CSS-Color can be entered, use rgba() to use transparency',
        },
        radialcolor_inactive: {
          baseType: "STRING",
          defaultValue: "rgba(219,219,219,1)",
          isVisible: true,
          isEditable: true,
          description: 'Any valid CSS-Color can be entered, use rgba() to use transparency',
        },
        textcolor_value: {
          baseType: "STRING",
          defaultValue: "rgba(219,219,219,1)",
          isVisible: true,
          isEditable: true,
          description: '(percentage in center) Any valid CSS-Color can be entered, use rgba() to use transparency',
        },
        textcolor_label: {
          baseType: "STRING",
          defaultValue: "rgba(219,219,219,1)",
          isVisible: true,
          isEditable: true,
          description: '(label beneath graph) Any valid CSS-Color can be entered, use rgba() to use transparency',
        }
      }
    };
  };
  
  var thisWidget = this;
  
  this.onClick = function(event) {
    // do nothing
    console.log('Click!');
  };
  
  this.getDiameter = function() {
	var elid  = thisWidget.jqElementId;
    var width = this.getProperty('Width', 0);
    var height = this.getProperty('Height', 0);
    // what if we don't get a value or it's zero?
    if (width <= 0) {
      // get the size of the 'bounding-box'-Element (parent of this.jqElement)
      // jqElement will probably be 0*0px
      var parent = jQuery(document.getElementById(elid)).parent();
      width = parent.width();
      height = parent.height();
      // well... try to use css-value directly (will fail too)
      if (width <= 0) {
        width = parent.css('width');
      }
      if (height <= 0) {
        height = parent.css('height');
      }
      // still zero? use default!
      if (width <= 0 || width === '0px') {
        width = 200;
      }
    }
    // now get the smaller size of height and width
    // because we'd like to draw a circle
    if (height > 0 && height < width) {
      return height;
    }
    return width;
  }
  
  this.centerRadial = function(radial) {
    var width = this.getProperty('Width', 0);
    var height = this.getProperty('Height', 0);
    var diameter   = this.getDiameter();
    if (width > diameter) {
      // move rp1 to center by calculating
      var pos = (width - diameter) / 2;
      radial.css('position', 'relative');
      radial.css('left', pos+'px');
      radial.css('top','0px');
    } else if (height > diameter) {
	  var pos = (height - diameter) / 2;
      radial.css('position', 'relative');
      radial.css('top', pos+'px');
      radial.css('left','0px');
    } else {
      radial.css('left','0px');
      radial.css('top','0px');
    }
  }
  
  this.afterRender = function() {
    var elid  = thisWidget.jqElementId;
    var label = this.getProperty('label', "");
    var diameter = this.getDiameter();
    // we have not defined what color values > 100 should have, so we use red
    var arcColors = [this.getProperty('radialcolor_inactive'),this.getProperty('radialcolor_active'), 'red'];
   
    var value = this.getProperty('value', 0.5);
    if (label.length > 0) {
      this.rp1 = radialProgress(document.getElementById(elid))
                .label(label)
                .onClick(thisWidget.onClick)
                .diameter(diameter)
                .textColorLabel(this.getProperty('textcolor_label'))
                .textColorPercentage(this.getProperty('textcolor_value'))
                .arcColors(arcColors)
                .value(value)
                .render();  
    } else {
      this.rp1 = radialProgress(document.getElementById(elid))
                .onClick(thisWidget.onClick)
                .diameter(diameter)
                .textColorLabel(this.getProperty('textcolor_label'))
                .textColorPercentage(this.getProperty('textcolor_value'))
                .arcColors(arcColors)
                .value(value)
                .render();
    }
    this.centerRadial(this.jqElement.children('svg'));
    
  };
  
  this.afterSetProperty = function (name, value) {
    // we no longer care... there are too many properties that force us to redraw
    
    //if (['value','width','height'].includes(name.toLowerCase())) {
    //  // things that force us to redraw
      return true;
    //} else {
    //  // things that don't
    //  return false;
    //}
  };
   
  this.renderHtml = function () {
    var color = this.getProperty('backgroundColor', '#fff');
    var style = TW.getStyleFromStyleDefinition(color);
    if (style.styleDefinitionName != undefined) {
      color = style.backgroundColor;
    }
    console.log(color);
    return "<div class=\"widget-content widget-radial\" style=\"background: "+color+"\"></div>";
  };
  
  this.widgetEvents = function () {
    return {
      'Changed': { 'warnIfNotBound': true },
      'Clicked': { 'warnIfNotBound': true }
    };
  };
};
