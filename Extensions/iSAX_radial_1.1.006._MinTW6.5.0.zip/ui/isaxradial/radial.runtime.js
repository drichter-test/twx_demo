TW.Runtime.Widgets.isaxradial = function () {
  this.percent = this.getProperty('value', 0.5);
  
  this.renderHtml = function () {
    return "<div class=\"widget-content widget-radial\"></div>";
  };
   
  var thisWidget = this;
  
  this.onClick = function(event) {
    // do nothing
  };
  
  this.getDiameter = function() {
	var elid  = thisWidget.jqElementId;
    var width = this.getProperty('Width', 0);
    var height = this.getProperty('Height', 0);
    // what if we don't get a value or it's zero?
    if (width <= 0) {
      // get the size of the 'bounding-box'-Element (parent of this.jqElement)
      // jqElement will probably be 0*0px
      var parent = jQuery(document.getElementById(elid)).parent();
      width = parent.width();
      height = parent.height();
      // well... try to use css-value directly (will fail too)
      if (width <= 0) {
        width = parent.css('width');
      }
      if (height <= 0) {
        height = parent.css('height');
      }
      // still zero? use default!
      if (width <= 0 || width === '0px') {
        width = 200;
      }
    }
    // now get the smaller size of height and width
    // because we'd like to draw a circle
    if (height > 0 && height < width) {
      return height;
    }
    return width;
  }
  
  this.centerRadial = function(radial) {
	var elid  = thisWidget.jqElementId;
    var width = this.getProperty('Width', 0);
    var height = this.getProperty('Height', 0);
    var diameter   = this.getDiameter();
    if (width > diameter) {
      // move rp1 to center by calculating
      var pos = (width - diameter) / 2;
      radial.css('position', 'relative');
      radial.css('left', pos+'px');
      radial.css('top','0px');
    } else if (height > diameter) {
	  var pos = (height - diameter) / 2;
      radial.css('position', 'relative');
      radial.css('top', pos+'px');
      radial.css('left','0px');
    } else {
      radial.css('left','0px');
      radial.css('top','0px');
    }
  }
  
  this.afterRender = function() {
    var elid  = thisWidget.jqElementId;
    var label = this.getProperty('label', "");
    var diameter = this.getDiameter();
    // we have not defined what color values > 100 should have, so we use red
    var arcColors = [this.getProperty('radialcolor_inactive'),this.getProperty('radialcolor_active'), 'red'];
   
    var value = this.getProperty('value', 0.5);
    if (label.length > 0) {
      this.rp1 = radialProgress(document.getElementById(elid))
                .label(label)
                .onClick(thisWidget.onClick)
                .diameter(diameter)
                .textColorLabel(this.getProperty('textcolor_label'))
                .textColorPercentage(this.getProperty('textcolor_value'))
                .arcColors(arcColors)
                .value(value)
                .render();  
    } else {
      this.rp1 = radialProgress(document.getElementById(elid))
                .onClick(thisWidget.onClick)
                .diameter(diameter)
                .textColorLabel(this.getProperty('textcolor_label'))
                .textColorPercentage(this.getProperty('textcolor_value'))
                .arcColors(arcColors)
                .value(value)
                .render();
    }
    this.centerRadial(this.jqElement.children('svg'));
    
  };
  
  this.setProperty = function(name,value) {
    if (name == 'value') {
      this.percent = value;
      this.centerRadial(this.jqElement.children('svg'));
      this.rp1.value(value).render();
    }
    return true; // trigger redraw
  };

  this.afterSetProperty = function (name, value) {
    if (['value','width','height'].includes(name.toLowerCase())) {
      // things that force us to redraw
      return true;
    } else {
      // things that don't
      return false;
    }
  };
  
  this.updateProperty = function(updatePropertyInfo) {
    if (updatePropertyInfo && updatePropertyInfo.TargetProperty && updatePropertyInfo.TargetProperty == 'value') {
      this.setProperty('value',updatePropertyInfo.RawSinglePropertyValue);
    }
  };
  
  // prefer this kind instead of creating getProperty since we don't want to overwrite this for EVERYTHING
  // (and docs don't tell us how to query our parent for those vals we don't have ourself)
  this.getProperty_value = function() {
    return this.percent;
  };
  
  this.renderHtml = function () {
    var color = this.getProperty('backgroundColor', '#fff');
    var style = TW.getStyleFromStyleDefinition(color);
    if (style.styleDefinitionName != undefined) {
      color = style.backgroundColor;
    }
    console.log(color);
    return "<div class=\"widget-content widget-radial\" style=\"background: "+color+"\"></div>";
  };
};
