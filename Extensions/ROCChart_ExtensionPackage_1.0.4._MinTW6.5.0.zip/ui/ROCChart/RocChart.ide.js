﻿TW.IDE.Widgets.rocchart = function () {

    this.MAX_SERIES = 16;

    this.widgetProperties = function () {
        var properties = {
            'name': 'ROC Chart',
            'description': 'Displays an line chart',
            'category': ['Data', 'Charts'],
            'supportsLabel': false,
            'supportsAutoResize': true,
            'borderWidth': 1,
            'defaultBindingTargetProperty': 'Data',
            'properties': {
                'SingleDataSource': {
                    'description': 'Use a Single Data Source for All Series',
                    'defaultValue': true,
                    'baseType': 'BOOLEAN',
                    'isVisible': true
                },
                'NumberOfSeries': {
                    'description': 'Desired number of series in this chart',
                    'defaultValue': 8,
                    'baseType': 'NUMBER',
                    'isVisible': true
                },
                'Data': {
                    'description': 'Data source',
                    'isBindingTarget': true,
                    'isEditable': false,
                    'baseType': 'INFOTABLE',
                    'warnIfNotBoundAsTarget': true
                },
                'ChartType': {
                    'description': 'Type of chart',
                    'baseType': 'STRING',
                    'defaultValue': 'linemarker',
                    'isVisible' : false,
                    'selectOptions': [
                        { value: 'line', text: 'Line' },
                        { value: 'marker', text: 'Marker' },
                        { value: 'linemarker', text: 'Line/Marker' },
                        { value: 'bar', text: 'Bar' },
                        { value: 'area', text: 'Area' },
                        { value: 'areamarker', text: 'Area/Marker' }
                    ]
                },
                'ChartOrientation': {
                    'description': 'Chart orientation',
                    'baseType': 'STRING',
                    'defaultValue': 'vertical',
                    'isVisible' : false
                },
                'ChartStyle': {
                    'description': 'Chart overall style',
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultChartStyle'
                },
                'ChartAreaStyle': {
                    'description': 'Chart area style',
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultChartAreaStyle'
                },
                'ChartLegendStyle': {
                    'description': 'Chart legend style',
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultChartLegendStyle'
                },
                'ChartTitleStyle': {
                    'description': 'Chart title style',
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultChartTitleStyle'
                },
                'ChartIndicatorStyle': {
                    'description': 'Chart indicator style',
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultChartIndicatorStyle'
                },
                'SelectedItemStyle': {
                    'description': 'Selected item style',
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultChartSelectionStyle'
                },
                'ChartTitle': {
                    'description': 'Chart Title',
                    'baseType': 'STRING',
                    'isBindingTarget': true,
                    'defaultValue': '',
                    'isLocalizable': true
                },
                'ShowLegend': {
                    'description': 'Show or hide the legend',
                    'baseType': 'BOOLEAN',
                    'defaultValue': true
                },
                'LegendWidth': {
                    'description': 'Fixed legend width (if non-zero it will be used)',
                    'baseType': 'NUMBER',
                    'defaultValue': 0
                },
                'LegendLocation': {
                    'description': 'Desired legend location (none = hide legend)',
                    'baseType': 'STRING',
                    'defaultValue': 'right',
                    'selectOptions': [
                        { value: 'right', text: 'Right' },
                        { value: 'top', text: 'Top' },
                        { value: 'bottom', text: 'Bottom' },
                        { value: 'left', text: 'Left' }
                    ]
                },
                'LegendOrientation': {
                    'description': 'Desired legend orientation',
                    'baseType': 'STRING',
                    'defaultValue': 'vertical',
                    'selectOptions': [
                        { value: 'vertical', text: 'Vertical' },
                        { value: 'horizontal', text: 'Horizontal' }
                    ]
                },
                'MarkerSize': {
                    'description': 'Desired marker size',
                    'baseType': 'NUMBER',
                    'defaultValue': 3
                },
                'MarkerType': {
                    'description': 'Desired marker type',
                    'baseType': 'STRING',
                    'defaultValue': 'circle',
                    'selectOptions': [
                        { value: 'circle', text: 'Circle' },
                        { value: 'square', text: 'Square' },
                        { value: 'triangle', text: 'Triangle' },
                        { value: 'diamond', text: 'Diamond' },
                        { value: 'image', text: 'Image' }
                    ]
                },
//                'Smoothing': {
//                    'description': 'Line smoothing',
//                    'baseType': 'BOOLEAN',
//                    'defaultValue': false
//                },
                'XAxisField': {
                    'description': 'Field that will provide X axis values',
                    'baseType': 'FIELDNAME',
                    'sourcePropertyName': 'Data',
                    'isBindingTarget': true,
                    'baseTypeRestriction': 'NUMBER',
                    'isVisible': true
                },
                'XAxisTitle': {
                    'description': 'Title to be displayed on the X axis',
                    'baseType': 'STRING',
                    'defaultValue': ''
                },
                'ShowXAxis': {
                    'description': 'Show or hide X axis',
                    'baseType': 'BOOLEAN',
                    'defaultValue': true
                },
                'XAxisStyle': {
                    'description': 'Chart X axis style',
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultChartAxisStyle'
                },
                'XAxisFormat': {
                    'description': 'Format for X axis values',
                    'baseType': 'STRING',
                    'defaultValue' : '0000.0'
                },
                'XAxisMinimum': {
                    'isBindingTarget': true,
                    'isVisible': true,
                    'description': 'Minimum range for the X axis',
                    'baseType': 'NUMBER'
                },
                'XAxisMaximum': {
                    'isBindingTarget': true,
                    'isVisible': true,
                    'description': 'Maximum range for the X axis',
                    'baseType': 'NUMBER'
                },
                'XAxisAutoscale': {
                    'isVisible': true,
                    'description': 'Automatically scale the X axis',
                    'baseType': 'BOOLEAN',
                    'defaultValue': true
                },
                'XAxisZeroscale': {
                    'isVisible': true,
                    'description': 'Force a zero minimum when automatically scaling the X axis',
                    'baseType': 'BOOLEAN',
                    'defaultValue': false
                },
                'XAxisSmoothScaling': {
                    'isVisible': true,
                    'description': 'Attempt to use round values to scale the X axis',
                    'baseType': 'BOOLEAN',
                    'defaultValue': true
                },
                'XAxisIntervals': {
                    'description': 'Number of X axis chart intervals (affects ticks, grid)',
                    'baseType': 'NUMBER',
                    'defaultValue': 10
                },
                'XAxisMinorTicks': {
                    'description': 'Number of X axis minor ticks',
                    'baseType': 'NUMBER',
                    'defaultValue': 1
                },
                'XAxisLabels': {
                    'description': 'Number of X axis labels',
                    'baseType': 'NUMBER',
                    'defaultValue': 2
                },
                'ShowXAxisLabels': {
                    'description': 'Show X axis labels',
                    'baseType': 'BOOLEAN',
                    'defaultValue': true
                },
                'ShowXAxisTicks': {
                    'description': 'Show X axis ticks',
                    'baseType': 'BOOLEAN',
                    'defaultValue': true
                },
                'AllowXAxisZoom': {
                    'description': 'Allow zooming the X axis',
                    'baseType': 'BOOLEAN',
                    'defaultValue': true
                },
                'ShowYAxis': {
                    'description': 'Show or hide Y axis',
                    'baseType': 'BOOLEAN',
                    'defaultValue': true
                },
                'YAxisMode': {
                    'description': 'Y axis mode',
                    'baseType': 'STRING',
                    'defaultValue': 'single',
                    'isVisible' : true,
                    'selectOptions': [
                        { value: 'single', text: 'Single Y Axis' },
                        { value: 'dual', text: 'Dual Y Axes' },
                        { value: 'multi', text: 'Multiple Y Axes' }
                    ]
                },
                'YAxisTitle': {
                    'description': 'Title to be displayed on the Y axis',
                    'baseType': 'STRING',
                    'defaultValue': ''
                },
                'YAxisStyle': {
                    'description': 'Chart Y axis style',
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultChartAxisStyle'
                },
                'YAxisIntervals': {
                    'description': 'Number of Y axis chart intervals (affects ticks, grid)',
                    'baseType': 'NUMBER',
                    'defaultValue': 10
                },
                'YAxisMinorTicks': {
                    'description': 'Number of Y axis minor ticks',
                    'baseType': 'NUMBER',
                    'defaultValue': 1
                },
                'YAxisLabels': {
                    'description': 'Number of Y axis labels',
                    'baseType': 'NUMBER',
                    'defaultValue': 2
                },
                'ShowYAxisLabels': {
                    'description': 'Show Y axis labels',
                    'baseType': 'BOOLEAN',
                    'defaultValue': true
                },
                'ShowYAxisTicks': {
                    'description': 'Show Y axis ticks',
                    'baseType': 'BOOLEAN',
                    'defaultValue': true
                },
                'AllowYAxisZoom': {
                    'description': 'Allow zooming the Y axis',
                    'baseType': 'BOOLEAN',
                    'defaultValue': true
                },
                'YAxisFormat': {
                    'description': 'Format for Y axis values',
                    'baseType': 'STRING',
                    'defaultValue' : '0000.0'
                },
                'YAxisMinimum': {
                    'isBindingTarget': true,
                    'isVisible': true,
                    'description': 'Minimum range for the Y axis',
                    'baseType': 'NUMBER',
                    'defaultValue': 0.0
                },
                'YAxisMaximum': {
                    'isBindingTarget': true,
                    'isVisible': true,
                    'description': 'Maximum range for the Y axis',
                    'baseType': 'NUMBER',
                    'defaultValue': 100.0
                },
                'YAxisAutoscale': {
                    'description': 'Automatically scale the Y axis',
                    'baseType': 'BOOLEAN',
                    'defaultValue': true
                },
                'YAxisZeroscale': {
                    'isVisible': true,
                    'description': 'Force a zero minimum when automatically scaling the Y axis',
                    'baseType': 'BOOLEAN',
                    'defaultValue': false
                },
                'SecondaryYAxisFormat': {
                    'description': 'Format for secondary Y axis values',
                    'baseType': 'STRING',
                    'defaultValue' : '0000.0'
                },
                'SecondaryYAxisMinimum': {
                    'isBindingTarget': true,
                    'isVisible': true,
                    'description': 'Minimum range for the secondary Y axis',
                    'baseType': 'NUMBER',
                    'defaultValue': 0.0
                },
                'SecondaryYAxisMaximum': {
                    'isBindingTarget': true,
                    'isVisible': true,
                    'description': 'Maximum range for the secondary Y axis',
                    'baseType': 'NUMBER',
                    'defaultValue': 100.0
                },
                'SecondaryYAxisAutoscale': {
                    'description': 'Automatically scale the secondary Y axis',
                    'baseType': 'BOOLEAN',
                    'defaultValue': true
                },
                'SecondaryYAxisZeroscale': {
                    'isVisible': true,
                    'description': 'Force a zero minimum when automatically scaling the secondary Y axis',
                    'baseType': 'BOOLEAN',
                    'defaultValue': false
                },
                'AllowSelection': {
                    'description': 'Allow item selection',
                    'baseType': 'BOOLEAN',
                    'isVisible': true,
                    'defaultValue': true
                },
                'EnableHover': {
                    'description': 'Enable display of values on hover',
                    'baseType': 'BOOLEAN',
                    'isVisible': true,
                    'defaultValue': true
                },
                'ShowXAxisGrid': {
                    'description': 'Show horizontal grid',
                    'baseType': 'BOOLEAN',
                    'defaultValue': true
                },
                'ShowYAxisGrid': {
                    'description': 'Show vertical grid',
                    'baseType': 'BOOLEAN',
                    'defaultValue': true
                },
                'GridStyle': {
                    'description': 'Chart grid style',
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultChartGridStyle'
                },
                'Width': {
                    'defaultValue': 640
                },
                'Height': {
                    'defaultValue': 240
                }
            }
        };
        
        var seriesNumber;
        for (seriesNumber = 1; seriesNumber <= this.MAX_SERIES; seriesNumber++) {
            var datasetProperty = {
                'description': 'Series data source ' + seriesNumber,
                'isBindingTarget': true,
                'isEditable': false,
                'baseType': 'INFOTABLE',
                'warnIfNotBoundAsTarget': false,
                'isVisible': true
            };

            var datalabelProperty = {
                'description': 'Series data label ' + seriesNumber,
                'baseType': 'STRING',
                'isBindingTarget': true,
                'isVisible': true,
                'isLocalizable': true
            };

            var datafieldProperty = {
                'description': 'Series data field ' + seriesNumber,
                'baseType': 'FIELDNAME',
                'sourcePropertyName': 'Data',
                'isBindingTarget': true,
                'baseTypeRestriction': 'NUMBER',
                'isVisible': true
            };

            var xaxisfieldProperty = {
                'description': 'Series X axis field ' + seriesNumber,
                'baseType': 'FIELDNAME',
                'sourcePropertyName': 'Data',
                'isBindingTarget': true,
                'baseTypeRestriction': 'NUMBER',
                'isVisible': true
            };

            var seriestypeProperty = {
                'description': 'Series type',
                'baseType': 'STRING',
                'defaultValue' : 'chart',
                'selectOptions': [
                    { value: 'chart', text: 'Use Chart Settings' },
                    { value: 'line', text: 'Line' },
                    { value: 'linemarker', text: 'Line/Marker' },
                    { value: 'marker', text: 'Marker' }
                ]
            };
            
            var seriesmarkertypeProperty = {
                'description': 'Series-specific marker type',
                'baseType': 'STRING',
                'defaultValue': 'chart',
                'selectOptions': [
                    { value: 'chart', text: 'Use Chart Settings' }
                ]
            };
                
            var seriesStyleProperty = {
                'description': 'Series style ' + seriesNumber,
                'baseType': 'STYLEDEFINITION',
                'isVisible': true
            };

            var seriesDataStyleProperty = {
                'description': 'Series data style ' + seriesNumber,
                'baseType': 'STATEFORMATTING',
                'baseTypeInfotableProperty': 'Data',
                'isVisible': true
            };

            var seriesUseSecondaryYAxisProperty = {
                'description': 'Use the secondary Y axis',
                'baseType': 'BOOLEAN',
                'defaultValue' : false,
                'isVisible' : true
            };
                    
            var seriescustomAxisFormatProperty = {
                'description': 'Format for axis values',
                'baseType': 'STRING',
                'defaultValue' : '0000.0',
                'isVisible' : false
            };
            
            var seriescustomAxisMinimumProperty = {
                'isBindingTarget': true,
                'isVisible': true,
                'description': 'Minimum range for the axis',
                'baseType': 'NUMBER',
                'defaultValue': 0.0,
                'isVisible' : false
            };
            
            var seriescustomAxisMaximumProperty = {
                'isBindingTarget': true,
                'isVisible': true,
                'description': 'Maximum range for the axis',
                'baseType': 'NUMBER',
                'defaultValue': 100.0,
                'isVisible' : false
            };
            
            var seriescustomAxisAutoscaleProperty = {
                'description': 'Automatically scale the axis',
                'baseType': 'BOOLEAN',
                'defaultValue': true,
                'isVisible' : false
            };
            
            var seriescustomAxisZeroscaleProperty = {
                'isVisible': true,
                'description': 'Force a zero minimum when automatically scaling the Y axis',
                'baseType': 'BOOLEAN',
                'defaultValue': false,
                'isVisible' : false
            };
            
            properties.properties['DataSource' + seriesNumber] = datasetProperty;
            properties.properties['DataField' + seriesNumber] = datafieldProperty;
            properties.properties['DataLabel' + seriesNumber] = datalabelProperty;
            properties.properties['XAxisField' + seriesNumber] = xaxisfieldProperty;
            properties.properties['SeriesType' + seriesNumber] = seriestypeProperty;
            properties.properties['SeriesMarkerType' + seriesNumber] = seriesmarkertypeProperty;
            properties.properties['UseSecondaryAxis' + seriesNumber] = seriesUseSecondaryYAxisProperty;
            properties.properties['AxisFormat' + seriesNumber] = seriescustomAxisFormatProperty;
            properties.properties['AxisMinimum' + seriesNumber] = seriescustomAxisMinimumProperty;
            properties.properties['AxisMaximum' + seriesNumber] = seriescustomAxisMaximumProperty;
            properties.properties['AxisAutoscale' + seriesNumber] = seriescustomAxisAutoscaleProperty;
            properties.properties['AxisZeroscale' + seriesNumber] = seriescustomAxisZeroscaleProperty;
            properties.properties['SeriesStyle' + seriesNumber] = seriesStyleProperty;
            properties.properties['SeriesStyle' + seriesNumber]['defaultValue'] = 'DefaultChartStyle' + seriesNumber;
            properties.properties['SeriesDataStyle' + seriesNumber] = seriesDataStyleProperty;
        }

        return properties;
    };

    this.setSeriesAxisProperties = function(value) {
        var allWidgetProps = this.allWidgetProperties();

        var mode = this.getProperty('YAxisMode');
        
        var seriesNumber;

        if(mode == 'multi') {
            for (seriesNumber = 1; seriesNumber <= value; seriesNumber++) {
                allWidgetProps['properties']['UseSecondaryAxis' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisFormat' + seriesNumber]['isVisible'] = true;
                allWidgetProps['properties']['AxisMinimum' + seriesNumber]['isVisible'] = true;
                allWidgetProps['properties']['AxisMaximum' + seriesNumber]['isVisible'] = true;
                allWidgetProps['properties']['AxisAutoscale' + seriesNumber]['isVisible'] = true;
                allWidgetProps['properties']['AxisZeroscale' + seriesNumber]['isVisible'] = true;
            }
            for (seriesNumber = value + 1; seriesNumber <= this.MAX_SERIES; seriesNumber++) {
                allWidgetProps['properties']['UseSecondaryAxis' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisFormat' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisMinimum' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisMaximum' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisAutoscale' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisZeroscale' + seriesNumber]['isVisible'] = false;
            }
        }
        else if(mode == 'dual') {
            for (seriesNumber = 1; seriesNumber <= value; seriesNumber++) {
                allWidgetProps['properties']['UseSecondaryAxis' + seriesNumber]['isVisible'] = true;
                allWidgetProps['properties']['AxisFormat' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisMinimum' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisMaximum' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisAutoscale' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisZeroscale' + seriesNumber]['isVisible'] = false;
            }
            for (seriesNumber = value + 1; seriesNumber <= this.MAX_SERIES; seriesNumber++) {
                allWidgetProps['properties']['UseSecondaryAxis' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisFormat' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisMinimum' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisMaximum' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisAutoscale' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisZeroscale' + seriesNumber]['isVisible'] = false;
            }
        }
        else {
            for (seriesNumber = 1; seriesNumber <= value; seriesNumber++) {
                allWidgetProps['properties']['UseSecondaryAxis' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisFormat' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisMinimum' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisMaximum' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisAutoscale' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisZeroscale' + seriesNumber]['isVisible'] = false;
            }
            for (seriesNumber = value + 1; seriesNumber <= this.MAX_SERIES; seriesNumber++) {
                allWidgetProps['properties']['UseSecondaryAxis' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisFormat' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisMinimum' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisMaximum' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisAutoscale' + seriesNumber]['isVisible'] = false;
                allWidgetProps['properties']['AxisZeroscale' + seriesNumber]['isVisible'] = false;
            }
        }
    };
    
    this.setSeriesProperties = function (value, singleSource) {
        var allWidgetProps = this.allWidgetProperties();

        var seriesNumber;

        for (seriesNumber = 1; seriesNumber <= value; seriesNumber++) {
            allWidgetProps['properties']['DataField' + seriesNumber]['isVisible'] = true;
            allWidgetProps['properties']['DataSource' + seriesNumber]['isVisible'] = !singleSource;
            allWidgetProps['properties']['XAxisField' + seriesNumber]['isVisible'] = !singleSource;
            allWidgetProps['properties']['SeriesStyle' + seriesNumber]['isVisible'] = true;
            allWidgetProps['properties']['SeriesType' + seriesNumber]['isVisible'] = false;
            allWidgetProps['properties']['SeriesMarkerType' + seriesNumber]['isVisible'] = true;
            allWidgetProps['properties']['SeriesDataStyle' + seriesNumber]['isVisible'] = true;
            allWidgetProps['properties']['DataLabel' + seriesNumber]['isVisible'] = true;
        }

        for (seriesNumber = value + 1; seriesNumber <= this.MAX_SERIES; seriesNumber++) {
            allWidgetProps['properties']['DataField' + seriesNumber]['isVisible'] = false;
            allWidgetProps['properties']['DataSource' + seriesNumber]['isVisible'] = false;
            allWidgetProps['properties']['XAxisField' + seriesNumber]['isVisible'] = false;
            allWidgetProps['properties']['SeriesStyle' + seriesNumber]['isVisible'] = false;
            allWidgetProps['properties']['SeriesType' + seriesNumber]['isVisible'] = false;
            allWidgetProps['properties']['SeriesMarkerType' + seriesNumber]['isVisible'] = false;
            allWidgetProps['properties']['SeriesDataStyle' + seriesNumber]['isVisible'] = false;
            allWidgetProps['properties']['DataLabel' + seriesNumber]['isVisible'] = false;
        }

        if (singleSource) {
            for (seriesNumber = 1; seriesNumber <= this.MAX_SERIES; seriesNumber++) {
                allWidgetProps['properties']['DataField' + seriesNumber]['sourcePropertyName'] = 'Data';
                allWidgetProps['properties']['XAxisField' + seriesNumber]['sourcePropertyName'] = 'Data';
                allWidgetProps['properties']['SeriesDataStyle' + seriesNumber]['baseTypeInfotableProperty'] = 'Data';
            }

            allWidgetProps['properties']['Data']['isVisible'] = true;
            allWidgetProps['properties']['XAxisField']['isVisible'] = true;
        }
        else {
            for (seriesNumber = 1; seriesNumber <= this.MAX_SERIES; seriesNumber++) {
                allWidgetProps['properties']['DataField' + seriesNumber]['sourcePropertyName'] = 'DataSource' + seriesNumber;
                allWidgetProps['properties']['XAxisField' + seriesNumber]['sourcePropertyName'] = 'DataSource' + seriesNumber;
                allWidgetProps['properties']['SeriesDataStyle' + seriesNumber]['baseTypeInfotableProperty'] = 'DataSource' + seriesNumber;
            }
            allWidgetProps['properties']['Data']['isVisible'] = false;
            allWidgetProps['properties']['XAxisField']['isVisible'] = false;
        }
    };

    this.widgetEvents = function () {
        return {
        	'DoubleClicked': {}
        };
    };

    this.renderHtml = function () {
        var html = '';
        html += '<div class="widget-content widget-rocchart"><table height="100%" width="100%"><tr><td valign="middle" align="center"><span>ROC Chart</span></td></tr></table></div>';
        return html;
    };


    this.afterLoad = function () {
        this.setSeriesProperties(this.getProperty('NumberOfSeries'), this.getProperty('SingleDataSource'));
        this.setSeriesAxisProperties(this.getProperty('NumberOfSeries'));
    };

    this.afterSetProperty = function (name, value) {
        if (name === 'Width' || name === 'Height') {
            return true;
        }

        if (name.indexOf('YAxisMode') === 0) {
            this.setSeriesAxisProperties(this.getProperty('NumberOfSeries'));
            this.updatedProperties();

            return true;
        }
        
        if (name === 'NumberOfSeries' || name === 'SingleDataSource') {

            this.setSeriesProperties(this.getProperty('NumberOfSeries'), this.getProperty('SingleDataSource'));
            this.updatedProperties();

            return true;
        }
    };
    
    this.beforeSetProperty = function (name, value) {
        if (name === 'NumberOfSeries') {
            value = parseInt(value, 10);
            if (value <= 0 || value > 16)
                return "Number Of Series Must Be Between 1 and 16";
        }
    };

    this.validate = function () {
        var result = [];

        if (!this.isPropertyBoundAsTarget('Data')) {
        	var bound = false;
        	
            for (var seriesNumber = 1; seriesNumber <= this.getProperty('NumberOfSeries'); seriesNumber++) {
                var dsProperty = 'DataSource' + seriesNumber;
                if(this.isPropertyBoundAsTarget(dsProperty)) {
                	bound = true;
                	break;
                }
            }
            
            if(!bound)
            	result.push({ severity: 'warning', message: 'You must assign at least one data source' });
        }
        return result;
    };
    

    this.afterAddBindingSource = function (bindingInfo) {
        if (bindingInfo.targetProperty == "Data") {
            this.setProperty('SingleDataSource', true);

            this.setSeriesProperties(this.getProperty('NumberOfSeries'), this.getProperty('SingleDataSource'));
            this.updatedProperties();
        }
    };};