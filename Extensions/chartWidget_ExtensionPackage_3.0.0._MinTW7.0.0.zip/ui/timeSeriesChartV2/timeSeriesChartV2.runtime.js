﻿/*global Encoder,TW */

var TW_timeSeriesChartV2IsExtension;

(function () {

    var addedDefaultChartStyles = false;

    TW.Runtime.Widgets.timeSeriesChartV2 = function () {
        var thisWidget = this,
            widgetProperties,
            widgetContainer,
            widgetContainerId,
            chart,
            chartContainer,
            chartContainerId,
            emptyChart,
            purge,
            MAX_SERIES = 8,
            chartStyles = {},
            dataLabels = [],
            scaleControlsCreated = false,
            valueUnderMouse = {},
            clickedRowId,
            selectedRowIndices,
            chartTitleTextSizeClass,
            chartTitleStyle,
            isResponsive = false,
            isInHiddenTab = false,
            isInHiddenBrowserTab,
            mashupParamDataSources = false,
            scaling="time",
            resizeHandler;

        thisWidget.chartData = null;
        thisWidget.processing = false;
        thisWidget.returnData = [];
        thisWidget.dynamicSeries = undefined;
        thisWidget.singleDataSource = thisWidget.getProperty('SingleDataSource');
        thisWidget.nSeries = Math.min(MAX_SERIES, thisWidget.getProperty('NumberOfSeries'));
        thisWidget.title = thisWidget.getProperty('ChartTitle');
        thisWidget.titleAlignment = thisWidget.getProperty("ChartTitleAlignment");
        thisWidget.xAxisLabel = thisWidget.getProperty('X-AxisLabel');
        thisWidget.yAxisLabel = thisWidget.getProperty('Y-AxisLabel');
        thisWidget.showAxisLabels = thisWidget.getProperty('ShowAxisLabels');
        thisWidget.showXAxisLabels = thisWidget.getProperty('ShowX-AxisLabels');
        thisWidget.showYAxisLabels = thisWidget.getProperty('ShowX-AxisLabels');
        thisWidget.showZoomStrip = thisWidget.getProperty('ShowZoomStrip');
        thisWidget.showInteractiveGuideline = thisWidget.getProperty('ShowInteractiveGuideline');
        thisWidget.showLegend = thisWidget.getProperty('ShowLegend');
        thisWidget.interpolation = thisWidget.getProperty('Interpolation');
        thisWidget.duration = thisWidget.getProperty('Duration');
        thisWidget.fillArea = Boolean(thisWidget.getProperty('FillArea'));
        thisWidget.labelAngle = thisWidget.getProperty('LabelAngle')*-1;
        thisWidget.xAxisIntervals = thisWidget.getProperty('X-AxisIntervals');
        thisWidget.xAxisMinMaxVisible = Boolean(thisWidget.getProperty('ShowX-AxisMinMax'));
        thisWidget.yAxisMinimum = thisWidget.getProperty('YAxisMinimum')*1;
        thisWidget.yAxisMaximum = thisWidget.getProperty('YAxisMaximum')*1;
        thisWidget.autoScale = Boolean(thisWidget.getProperty('AutoScale'));
        thisWidget.yAxisIntervals = thisWidget.getProperty('YAxisIntervals');
        thisWidget.yAxisMinMaxVisible = thisWidget.getProperty('ShowY-AxisMinMax');
        thisWidget.margins = thisWidget.getProperty('Margins');
        thisWidget.width = thisWidget.getProperty('Width');
        thisWidget.height = thisWidget.getProperty('Height');
        thisWidget.zIndex = thisWidget.getProperty('Z-index');
        thisWidget.selectedItems = [];
        thisWidget.enableSelection = true;
        thisWidget.toggleScaling = true;
        thisWidget.xAxisField = thisWidget.getProperty('X-AxisField');
        thisWidget.timeScale = thisWidget.getProperty('TimeScale');
        thisWidget.timeFormat = thisWidget.timeScale==='y' ? thisWidget.getProperty('DateOrder') : thisWidget.timeScale;
        thisWidget.reSort = thisWidget.getProperty('Re-Sort');

        (function () {
            var hidden = "hidden";
            // Standards:
            if (hidden in document) {
                document.addEventListener("visibilitychange", onchange);
            } else if ((hidden = "mozHidden") in document) {
                document.addEventListener("mozvisibilitychange", onchange);
            } else if ((hidden = "webkitHidden") in document) {
                document.addEventListener("webkitvisibilitychange", onchange);
            } else if ((hidden = "msHidden") in document) {
                document.addEventListener("msvisibilitychange", onchange);
        }

    function onchange(evt) {
        var v = "visible", h = "hidden",
        evtMap = { focus: v,focusin: v,pageshow: v,blur: h,focusout: h,pagehide: h};
        evt = evt || window.event;
        if (evt.type in evtMap) {
          document.body.className = evtMap[evt.type];
          isInHiddenBrowserTab = evtMap[evt.type].charAt(0)==="h";
        } else {
          document.body.className = this[hidden] ? "hidden" : "visible";
          isInHiddenBrowserTab = this[hidden];
        }
    }

    // set the initial state (but only if browser supports the Page Visibility API)
    if (document[hidden] !== undefined) {
        onchange({type: document[hidden] ? "blur" : "focus"});
    }
})();
                                                                               this.runtimeProperties = function () {
            return {
                'needsDataLoadingAndError': false
            };
        };

        this.renderHtml = function () {
            chartTitleStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('ChartTitleStyle', 'DefaultChartTitleStyle'));

            chartTitleTextSizeClass = 'textsize-normal';
            if (this.getProperty('ChartTitleStyle') !== undefined) {
                chartTitleTextSizeClass = TW.getTextSizeClassName(chartTitleStyle.textSize);
            }

            thisWidget.id = thisWidget.getProperty('Id');
            var html =
                '<div class="timeSeriesChartV2-content widget-timeSeriesChartV2" id="' + thisWidget.jqElementId + '" style=" z-index: '+thisWidget.zIndex +';" >' +
                '<div class="chart-title ' + chartTitleTextSizeClass + '" id="' + thisWidget.jqElementId + '-title" style=" text-align:' + (thisWidget.titleAlignment || 'center') + ';">' +
                    '<span class="widget-chart-title-text" style="Margin: 0 1em 0 1em;">'+ Encoder.htmlEncode(thisWidget.title) + '</span>' +
                '</div>' +
                '</div>';

            // if running as extension, call renderStyles
            if (TW_timeSeriesChartV2IsExtension){
                thisWidget.renderStyles();
            }

            return html;
        };

        this.renderStyles = function () {

            var formatResult = TW.getStyleFromStyleDefinition(thisWidget.getProperty('ChartBodyStyle', 'DefaultChartBodyStyle'));
            chartTitleStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('ChartTitleStyle', 'DefaultChartTitleStyle'));
            var chartAxisStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('ChartAxisStyle', 'DefaultChartAxisStyle'));
            var chartTitleStyleBG = TW.getStyleCssGradientFromStyle(chartTitleStyle);
            var chartTitleStyleText = TW.getStyleCssTextualNoBackgroundFromStyle(chartTitleStyle);
            //var chartFocusStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('FocusStyle', 'DefaultButtonFocusStyle'));
            var chartBackground = TW.getStyleCssGradientFromStyle(formatResult);
            var chartBorder = TW.getStyleCssBorderFromStyle(formatResult);
            // chart series lines are stroked in color in svg processing, not in css
            // to be replaced with iterator on however many series/styles were set up
            var chartStyle1 = TW.getStyleFromStyleDefinition(thisWidget.getProperty('SeriesStyle1','DefaultChartStyle1'));
            var chartStyle2 = TW.getStyleFromStyleDefinition(thisWidget.getProperty('SeriesStyle2','DefaultChartStyle2'));
            var chartStyle3 = TW.getStyleFromStyleDefinition(thisWidget.getProperty('SeriesStyle3','DefaultChartStyle3'));
            var chartStyle4 = TW.getStyleFromStyleDefinition(thisWidget.getProperty('SeriesStyle4','DefaultChartStyle4'));
            var chartStyle5 = TW.getStyleFromStyleDefinition(thisWidget.getProperty('SeriesStyle5','DefaultChartStyle5'));
            var chartStyle6 = TW.getStyleFromStyleDefinition(thisWidget.getProperty('SeriesStyle6','DefaultChartStyle6'));
            var chartStyle7 = TW.getStyleFromStyleDefinition(thisWidget.getProperty('SeriesStyle7','DefaultChartStyle7'));
            var chartStyle8 = TW.getStyleFromStyleDefinition(thisWidget.getProperty('SeriesStyle8','DefaultChartStyle8'));
            var chartStrokeStyle1 = TW.getStyleCssBorderFromStyle(chartStyle1);
            var chartStrokeStyle2 = TW.getStyleCssBorderFromStyle(chartStyle2);
            var chartStrokeStyle3 = TW.getStyleCssBorderFromStyle(chartStyle3);
            var chartStrokeStyle4 = TW.getStyleCssBorderFromStyle(chartStyle4);
            var chartStrokeStyle5 = TW.getStyleCssBorderFromStyle(chartStyle5);
            var chartStrokeStyle6 = TW.getStyleCssBorderFromStyle(chartStyle6);
            var chartStrokeStyle7 = TW.getStyleCssBorderFromStyle(chartStyle7);
            var chartStrokeStyle8 = TW.getStyleCssBorderFromStyle(chartStyle8);
            chartStyles.series1 = chartStyle1.lineColor;
            chartStyles.series1StrokeWidth = getStrokeWidth(chartStrokeStyle1);
            //chartStyles.series1StrokeStyle = getStrokeStyle(chartStrokeStyle1);
            //console.log(" chartStyles.series1StrokeStyle : "+ chartStyles.series1StrokeStyle);
            chartStyles.series2 = chartStyle2.lineColor;
            chartStyles.series2StrokeWidth = getStrokeWidth(chartStrokeStyle2);
            chartStyles.series3 = chartStyle3.lineColor;
            chartStyles.series3StrokeWidth = getStrokeWidth(chartStrokeStyle3);
            chartStyles.series4 = chartStyle4.lineColor;
            chartStyles.series4StrokeWidth = getStrokeWidth(chartStrokeStyle4);
            chartStyles.series5 = chartStyle5.lineColor;
            chartStyles.series5StrokeWidth = getStrokeWidth(chartStrokeStyle5);
            chartStyles.series6 = chartStyle6.lineColor;
            chartStyles.series6StrokeWidth = getStrokeWidth(chartStrokeStyle6);
            chartStyles.series7 = chartStyle7.lineColor;
            chartStyles.series7StrokeWidth = getStrokeWidth(chartStrokeStyle7);
            chartStyles.series8 = chartStyle8.lineColor;
            chartStyles.series8StrokeWidth = getStrokeWidth(chartStrokeStyle8);
            var styleBlock = '';

            var chartCssInfo = TW.getStyleCssTextualNoBackgroundFromStyle(formatResult);
            var chartLineInfo = TW.getStyleCssBorderFromStyle(chartAxisStyle);

            // d3 uses color values directly
            chartStyles.text = chartCssInfo.split(';')[0].split(':')[1];
            chartStyles.gridStyle = chartLineInfo.split(';')[1].split(':')[1];
            chartStyles.chartBackground = chartBackground.split(';')[0].split(':')[1];
            //regular widget styles
            if (thisWidget.getProperty('ChartBodyStyle', 'DefaultChartBodyStyle') === 'DefaultChartBodyStyle'
                && thisWidget.getProperty('ChartTitleStyle', 'DefaultChartTitleStyle') === 'DefaultChartTitleStyle'
                && thisWidget.getProperty('FocusStyle', 'DefaultButtonFocusStyle') === 'DefaultButtonFocusStyle') {
                if (!addedDefaultChartStyles) {
                    addedDefaultChartStyles = true;
                    // add chart title default style
                    var defaultStyles = '.chart-title {' + chartTitleStyleBG + ' ' + chartTitleStyleText + ' }' +
                    //  ' .widget-timeSeriesChartV2.focus {' + chartFocusBorder + '}' +
                        ' .widget-timeSeriesChartV2 {' + chartBackground +' '+ chartBorder +' }';
                    $.rule(defaultStyles).appendTo(TW.Runtime.globalWidgetStyleEl);
                }
            } else {
                // add custom chart title style
                styleBlock += '#' + thisWidget.jqElementId + ' .chart-title { ' + chartTitleStyleBG + ' ' + chartTitleStyleText + ' } ' +
                    '#' + thisWidget.jqElementId + '.widget-chart-title-text { ' + chartTitleStyle + ' }' +
                //    '#' + thisWidget.jqElementId + '.focus .widget-timeSeriesChartV2 {' + chartFocusBorder + '}' +
                    '#' + thisWidget.jqElementId + '.widget-timeSeriesChartV2 {' + chartBackground + chartBorder + '}';
            }

            return styleBlock;

            function getStrokeWidth(styleRef){
                if(styleRef !== "none") {
                    var widthPix = styleRef.split(';')[0].split(':')[1];
                    return widthPix.substring(0, widthPix.indexOf("px"))
                }
                return 1
            }
            
            function getStrokeStyle(styleRef){
                if(styleRef !== "none") {
                    var strokeStyle = styleRef.split(';')[2].split(':')[1];
                    // dashed, dotted, solid, none
                    switch(strokeStyle){
                        case 'dashed':
                            //set up d3 equivalent
                            return ["stroke-linecap", "miter", "stroke-dasharray", ("10,3")];
                            break;
                        case 'dotted' :
                            //d3 equivalent
                            return["stroke-linecap", "round", "stroke-dasharray", ("1,6")];
                            break;
                        case 'none':
                            // does it make sense to handle this?
                        default:
                            return["stroke-linecap", "bevel"];
                            break;
                    }
                }
                return 1
            }
        };

        this.afterRender = function () {
            widgetProperties = thisWidget.properties;
            widgetContainer = thisWidget.jqElementId;
            widgetContainerId = '#' + widgetContainer;
            chartContainer = widgetContainer + '-chart'; //root_nvd3line-6-chart
            chartContainerId = '#' + chartContainer; //#root_nvd3line-6-chart

            // look to see if chart is in a mashupContainer
            // class contains widget-mashupcontainer
            mashupParamDataSources = $(widgetContainerId).parents('.widget-mashupcontainer').length;
            var widgetSelector = widgetContainer + ' .-element';
            // add svg tag to html element required to inject chart
            $('<svg id="' + chartContainer + '" ></svg>').appendTo(widgetContainerId);

            // styles
            var chartTitleElement = $(widgetContainerId).find('.chart-title');
            chartTitleElement.switchClass('textsize-normal', chartTitleTextSizeClass);

            // events
            $(widgetSelector).on('focus', function () {
                $(widgetContainer).addClass('focus');
            });

            $(widgetSelector).on('blur', function (e) {
                $(widgetContainer).removeClass('focus');
            });

            thisWidget.jqElement.dblclick(thisWidget.dblClickHandler);

            thisWidget.jqElement.find('.nv-legend').on('click', function (e) {
                thisWidget.jqElement.triggerHandler('DoubleClicked');
                e.preventDefault();
            });

            if (thisWidget.properties.ResponsiveLayout) {
                isResponsive = true;
                $(widgetContainerId + '-bounding-box').height('100%').width('100%');
                $(widgetContainerId + '-bounding-box').css('overflow','hidden');
                $(widgetContainerId).height("100%").width("100%");
                $(chartContainerId).height("100%").width("100%");
                $(widgetContainerId).css('overflow','hidden');
            } else {
                $(chartContainerId).width(thisWidget.width + 20);
                $(chartContainerId).height(thisWidget.height - 24);
            }

            $(widgetContainerId + '-bounding-box').css('z-index',thisWidget.zIndex);
            
            // get unbound dataLabel strings
            for (var i = 1; i < thisWidget.nSeries + 1; i++) {
                var dataLabel = widgetProperties['DataLabel' + i];
                if (dataLabel !== undefined && dataLabel !== '') {
                    dataLabels.push(dataLabel);
                } else {
                    dataLabels.push("Series " + i);
                }
            }

            dataLabels = this.forceUniqueValues(dataLabels);
            // build empty chart if no data event is received
 //           emptyChart = setTimeout(function () {
 //              thisWidget.showEmptyChart("Time Series Chart Must Be Bound To Data")
 //           }, 1000);
            $(window).on('resize', _.debounce(thisWidget.processDataset,300));
        };

        this.updateProperty = function (updatePropertyInfo) {
            var thisWidget = this;
            var widgetProperties = thisWidget.properties;
            var seriesNumber;
            var nSeries = thisWidget.nSeries;

            // if this is in a inactive tab or similar we must prevent rendering until tab gets clicked
            if(isResponsive && $(widgetContainerId).closest('.tabsv2-actual-tab-contents').css('display')==='none') {
                isInHiddenTab = true;
                $(chartContainerId).hide();
            }else{
                isInHiddenTab = false;
                $(chartContainerId).fadeIn(thisWidget.duration);
            }

            if (updatePropertyInfo.TargetProperty === "ChartTitle") {
                var updatedTitle = updatePropertyInfo.RawSinglePropertyValue;
                thisWidget.setProperty('ChartTitle', updatedTitle);
                thisWidget.title = updatedTitle;
                $('#' + thisWidget.jqElementId + '-title').text(updatedTitle);
                return;
            }

            if (updatePropertyInfo.TargetProperty.indexOf('Data') === 0 && !isInHiddenBrowserTab && thisWidget.processing === false) {
                clearTimeout(emptyChart);
                thisWidget.dataRows = updatePropertyInfo.ActualDataRows;

                /*if (thisWidget.singleDataSource) {

                    // since x-axis was not set in ide, it is necessary to find fields to bind to based on date type
                    if (thisWidget.dynamicSeries) {
                        // take MAX_SERIES or nSeries if it is set, whichever is lower

                        // clear any possible properties set on series field names
                        for (seriesNumber = 1; seriesNumber <= nSeries; seriesNumber++) {
                            yAxisFieldName = 'DataField' + seriesNumber;
                            thisWidget.setProperty(yAxisFieldName, undefined);
                        }

                        seriesNumber = 1;

                        var dataShape = updatePropertyInfo.DataShape;

                        for (var fieldName in dataShape) {

                            var fieldDefinition = dataShape[fieldName];
                            // automatically set the x axis to the datetime field because this is a timeseries chart
                            //console.log("fieldDefinition.baseType: " + fieldDefinition.baseType + ", fieldName: " + fieldName);
                            if (fieldDefinition.baseType === 'DATETIME') {
                                thisWidget.setProperty('X-AxisField', fieldName);
                            }
                            // automatically set the y axis to the number field because convention?
                            if (fieldDefinition.baseType === 'NUMBER') {
                                if (seriesNumber <= nSeries) {
                                    yAxisFieldName = 'DataField' + seriesNumber;
                                    thisWidget.setProperty(yAxisFieldName, fieldName);
                                    seriesNumber = seriesNumber + 1;
                                }
                            }
                        }
                    }
                }
                */
                // iterate through the series fields
                if (updatePropertyInfo.TargetProperty === "Data") {
                    thisWidget.chartSeries = [];
                    for (seriesNumber = 1; seriesNumber <= nSeries; seriesNumber++) {

                        var dataField = widgetProperties['DataField' + seriesNumber];

                        if (dataField !== undefined && dataField !== '' && thisWidget.dataRows != undefined && thisWidget.dataRows.length !== 0) {

                            var seriesType = widgetProperties['SeriesType' + seriesNumber];

                            if (seriesType == 'chart' || seriesType === undefined || seriesType == null) {
                                seriesType = widgetProperties['ChartType'];
                            }

                            //this.enableSelection = widgetProperties['AllowSelection'];

                            var seriesDefinition = {
                                dataSource: updatePropertyInfo.TargetProperty,
                                field: dataField,
                                data: thisWidget.dataRows,
                                label: this.getProperty('DataLabel' + seriesNumber),
                                style: widgetProperties['SeriesStyle' + seriesNumber]
                            };
                            thisWidget.chartSeries.push(seriesDefinition);
                        }else{
                            TW.log.warn("dataField is empty or undefined");
                        }
                    }
                    if(! isInHiddenTab) {
                        thisWidget.liveData = this.processDataset();
                    }
                }else if (updatePropertyInfo.TargetProperty.indexOf('DataLabel') === 0) {
                    for (seriesNumber = 1; seriesNumber <= nSeries; seriesNumber++) {
                        var labelName = 'DataLabel' + seriesNumber.toString();
                        if (updatePropertyInfo.TargetProperty === labelName && updatePropertyInfo.RawSinglePropertyValue !== undefined) {
                            thisWidget.setProperty(labelName, updatePropertyInfo.RawSinglePropertyValue);
                            dataLabels = this.forceUniqueValues(dataLabels);
                            // replace the dataLabel by position in array dataLabels
                            dataLabels[seriesNumber - 1] = thisWidget.getProperty(labelName);
                            // set the label of the corresponding chartSeries element in liveData
                            thisWidget.liveData[seriesNumber - 1].key = dataLabels[seriesNumber - 1];
                            if(! isInHiddenTab) {
                                thisWidget.liveData = this.processDataset();
                            }
                        }
                    }
                } else {
                    // multiple datasource handling
                    if (thisWidget.dataRows !== undefined && thisWidget.dataRows.length > 0 && !thisWidget.singleDataSource) {
                        // each data load resets the purge timeout
                        // so we only purge after final data load in case some dataSources were deselected
                        clearTimeout(purge);
                        purge = setTimeout(function(){purgeDataSources(dataSourceId)}, 400);
                        var dataSourceName = updatePropertyInfo.TargetProperty;

                        //check if targetProperty is a dataSource already displayed
                        var newSeries = true;
                        
                        var dataSourceId = dataSourceName.substr(dataSourceName.length - 1, 1);
                        for (var i = 0; i < thisWidget.chartSeries.length; i++) {
                            // if the series' datasource is already in chartSeries
                            // or the id is greater than the max number of series allowed it is a repeat
                            if (thisWidget.chartSeries[i].dataSource === updatePropertyInfo.TargetProperty || dataSourceId > nSeries) {
                                newSeries = false;
                            }
                        }
                        
                        var dataField = widgetProperties['DataField' + dataSourceId];

                        var seriesDefinition = {
                            dataSource: dataSourceName,
                            id: dataSourceId,
                            field: dataField,
                            data: thisWidget.dataRows,
                            label: this.getProperty('DataLabel' + dataSourceId),
                            style: widgetProperties['SeriesStyle' + dataSourceId]
                        };

                        // if existing dataSource, update
                        if (newSeries === false) {
                            thisWidget.chartSeries.splice(dataSourceId - 1, 1, seriesDefinition);
                            //console.log("update thisWidget.chartSeries.splice(dataSourceId - 1: "+thisWidget.chartSeries[dataSourceId - 1]);
                            // replace the dataLabel by position in array dataLabels
                            dataLabels.splice(dataSourceId - 1, 1, seriesDefinition.label);
                            //console.log("update thisWidget.chartSeries.splice(dataLabels dataSourceId - 1: "+thisWidget.chartSeries[dataSourceId - 1] +", "+seriesDefinition.label);
                            // set the label of the corresponding chartSeries element in liveData
                            if(thisWidget.liveData !== undefined) {
                                thisWidget.liveData[dataSourceId].key = dataLabels[dataSourceId];
                            }
                        }

                        // if new dataSource, add
                        if (newSeries === true) {
                            // if max series already displayed, drop FIFO
                            if (thisWidget.chartSeries.length > nSeries) {
                                //console.log("dropping FIFO. chartSeries.label: "+thisWidget.chartSeries[0].label);
                                chartSeries.shift();
                                dataLabels.shift();
                            }
                            thisWidget.chartSeries.push(seriesDefinition);
                        }

                    }else{
                        TW.log.warn("data rows undefined or empty for targetProperty: " + updatePropertyInfo.TargetProperty);
                    }
                }
                if(! isInHiddenTab) {
                    thisWidget.liveData = this.processDataset();
                }
            }

            if(thisWidget.enableSelection) {

                var selectedRowIndices = updatePropertyInfo.SelectedRowIndices;

                if (selectedRowIndices !== undefined) {
                    //this is chart updating selection flags to match grid row
                    //TW.ChartLibrary.handleChartSelectionUpdate(this, this.chart, updatePropertyInfo.TargetProperty, selectedRowIndices);
                }
                else {
                    TW.ChartLibrary.handleChartSelectionUpdate(this, this.chart, updatePropertyInfo.TargetProperty, new Array());
                }
            }

        };

        function purgeDataSources(dataSourceId){
            // if dynamic binding via mashup parameters, nSeries is going to probably be 8 and you will
            // never drop/swap series right. For that case it might work to drop all datasources and build them up again.
            // But dropping all doesn't work if dataSeries are manually bound
            if(mashupParamDataSources){
                if(chartSeries.length>dataSourceId) {
                    //console.log("Purging. chartSeries.label: "+chartSeries[dataSourceId].label);
                    thisWidget.chartSeries.splice(dataSourceId, (thisWidget.chartSeries.length - dataSourceId));
                    if(! isInHiddenTab) {
                        thisWidget.liveData = thisWidget.processDataset();
                    }
                }
            }else{
                if(thisWidget.chartSeries.length > thisWidget.nSeries) {
                    //console.log("Purging. chartSeries.label: "+chartSeries[dataSourceId].label);
                    thisWidget.chartSeries.splice(dataSourceId, (thisWidget.chartSeries.length - thisWidget.nSeries));
                    thisWidget.chartSeries = [];
                    if(! isInHiddenTab) {
                        thisWidget.liveData = thisWidget.processDataset();
                    }
                }
            }
        }

        // take field 'series' of infoTable and return in this format to nvd3:
        /*
         {
         values: [{"x":timestamp,"y":1},{"x":timestamp,"y":2},{"x":timestamp,"y":3}],
         key: xfield,
         color: '#ff7f0e'
         }
         */
        this.processDataset = function () {
            thisWidget.processing = true;
            var nRows = 0,
            seriesFieldName,
            timeField,
            nSeries = thisWidget.nSeries,
            singleDataSource = thisWidget.singleDataSource;

            thisWidget.returnData = [];

            var nSeriesToProcess = singleDataSource ? nSeries : thisWidget.chartSeries.length;
            for (var i = 0; i < nSeriesToProcess; i++) {
                var dataSource = thisWidget.chartSeries[i];
                var data;
                timeField = singleDataSource ? thisWidget.xAxisField : thisWidget.getProperty('X-AxisField' + dataSource.id);
                if(dataSource !== undefined) {
                    seriesFieldName = dataSource.field;

                    if(thisWidget.reSort) {
                        data = sortBy(dataSource.data, timeField);
                    }else{
                        data = dataSource.data;
                    }
                }else{
                    var message = "Error: A " + ( singleDataSource ? "DataField" : "DataSource")+" needs to be selected";
                    thisWidget.showEmptyChart(message);
                    return;
                }

                if (seriesFieldName !== undefined && seriesFieldName != "") {
                    var timeStamp,
                    seriesValue,
                    seriesValues = [],
                    obj;

                    nRows = data.length;

                    for (var rowid = 0; rowid < nRows; rowid++) {
                        var row = data[rowid];
                        for (var key in row) {
                            // check if property is not inherited from prototype
                            /*
                            if (row.hasOwnProperty(key)) {
                                console.log("key: "+key);
                                var value = row[key];
                                console.log("value: "+value);
                            }
                            */
                        }

                        if (row[seriesFieldName] !== undefined && row[seriesFieldName] !== '' ) {
                            seriesValue = row[seriesFieldName];
                        } else {
                            TW.log.error('timeSeriesChartV2 widget extension, '+seriesFieldName + ' undefined or empty seriesValue forced to 0');
                            seriesValue = 0;
                        }
                        if (timeField !== undefined && row[timeField] !== undefined && row[timeField] !== '') {
                            timeStamp = row[timeField];
                        } else {
                            timeStamp = new Date();
                            TW.log.error('timeSeriesChartV2 widget extension, row timeField was not a date or was empty');
                        }

                        scaling==="time" ? obj = {"x": timeStamp, "y": seriesValue} : obj = {"x": rowid, "y": seriesValue};

                        //console.log("obj.x: "+obj.x+" obj.y: "+obj.y);
                        //console.log("pds obj.y: " + obj.y);
                        seriesValues.push(obj);
                    }
                    var seriesData = {
                        'values': seriesValues,
                        // key should be label prop w fallback to dataSourceName
                        'key': TW.Runtime.convertLocalizableString(dataLabels[i]),
                        'color': chartStyles['series' + (i + 1)],
                        'area': thisWidget.fillArea,
                        'strokeWidth': chartStyles['series'+(i+1)+'StrokeWidth'],
                        // for dotted and dashed lines: classed: 'dashed' or 'dotted' and then css to apply style
                    };
                    thisWidget.returnData.push(seriesData);
                }
            }

            if (thisWidget.returnData.length > 0 && !isInHiddenTab) {
                if(thisWidget.chartData){
                    $(chartContainerId).show();
                    thisWidget.update(thisWidget.returnData);
                }else {
                    thisWidget.render(thisWidget.returnData);
                }
                thisWidget.processing = false;
                return thisWidget.returnData;
            }
        };

        this.resize = function(width,height) {
            if ($(widgetContainerId).closest('.tabsv2-actual-tab-contents').css('display')==='block' && isInHiddenTab) {
                isInHiddenTab = false;
                thisWidget.processDataset();
            }
            $(chartContainerId).fadeIn(thisWidget.duration);
        };

        this.render = function (data, isUpdate) {
            $('.xy-tooltip').remove();
            var propMargin = thisWidget.margins.split(',');
            var xLabelMargin = (isResponsive ? 63 : 42) + propMargin[2]*1;
            var yLabelMargin = 56 + propMargin[1]*1;
            var legendMargin = 28 + propMargin[0]*1;
            var showLegend = thisWidget.showLegend === true && thisWidget.nSeries > 1;

            // this will create an empty data
            if (data === undefined) {
                TW.log.error('timeSeriesChartV2 widget extension, data undefined');
            }

            if (isUpdate !== undefined && isUpdate === true) {
                chartData.datum(data).transition().duration(thisWidget.duration).call(chart);
                if(!resizeHandler){
                    resizeHandler = nv.utils.windowResize(chart.update);
                }
            } else {
                nv.addGraph(function () {
                    // auto date formatter
                    var tickMultiFormat = d3.time.format.multi([
                        ["%-I:%M%p", function (d) {
                            return d.getMinutes();
                        }], // not the beginning of the hour
                        ["%-I%p", function (d) {
                            return d.getHours();
                        }], // not midnight
                        ["%b %-d", function (d) {
                            return d.getDate() != 1;
                        }], // not the first of the month
                        ["%b %-d", function (d) {
                            return d.getMonth();
                        }], // not Jan 1st
                        ["%Y", function () {
                            return true;
                        }]
                    ]);

                    chart = nv.models.lineChart();
                    //zoomStrip-only settings
                    chart.focusEnable( thisWidget.showZoomStrip );
                    chart.x2Axis
                        .tickFormat(function (d) {})
                        .showMaxMin(!!thisWidget.xAxisMinMaxVisible)
                        .ticks(thisWidget.xAxisIntervals)
                        .tickPadding(10);
                    chart.y2Axis
                        .showMaxMin(false);
                    chart.showYAxis(thisWidget.showYAxisLabels)
                        .showXAxis(thisWidget.showXAxisLabels);
                    chart.duration(thisWidget.duration);
                    if(thisWidget.showAxisLabels) {
                        chart.xAxis.axisLabel(thisWidget.xAxisLabel);
                        chart.yAxis.axisLabel(thisWidget.yAxisLabel);
                        yLabelMargin += isResponsive ? 14 : 7;
                        xLabelMargin += isResponsive ? 42 : 21;
                    }

                    if(!thisWidget.showAxisLabels && thisWidget.xAxisIntervals + thisWidget.yAxisIntervals > 0) {
                        yLabelMargin += 7;
                    }

                    // add margin if labelAngle used
                    if (thisWidget.labelAngle < 0) {
                        xLabelMargin += 28;
                        yLabelMargin += 14;
                    }
                    // add margin if legend displayed
                    if (showLegend) {
                        legendMargin += 7;
                    }
                    //add margin if showZoomStrip
                    if (thisWidget.timeScale === "%-I:%M:%S.%L%p") {
                        xLabelMargin += 21;
                        //thisWidget.jqElement.find('nv-axislabel', 'translateY(21px)');
                    }

                    // move the x axis label with .nv-axisLabel class label move lower
                    chart.margin({top: legendMargin, left: yLabelMargin, bottom: xLabelMargin, right: 49+(propMargin[3]*1)})  //Adjust chart margins to give the x-axis some breathing room.
                        .useInteractiveGuideline(thisWidget.showInteractiveGuideline)
                        //.duration(thisWidget.duration)  //how fast do you want the lines to transition?
                        .showLegend(showLegend)      //Show the legend, allowing users to turn on/off line series.
                        .height = thisWidget.height - xLabelMargin - legendMargin;

                    // set the y scale to user settings
                    if(thisWidget.autoScale===false && thisWidget.yAxisMinimum!=='') {

                        if(thisWidget.yAxisMaximum>thisWidget.yAxisMinimum){
                            chart.forceY([thisWidget.yAxisMinimum,thisWidget.yAxisMaximum]);
                        }else {
                            chart.forceY(thisWidget.yAxisMinimum);
                        }
                    }

                    chart.interpolate(thisWidget.interpolation);
                    // override default tooltip in interactive layer
                    if(thisWidget.ShowInteractiveGuideline) {
                        chart.interactiveLayer.tooltip.contentGenerator(function (d) {
                            return thisWidget.tooltipGenerator(d)
                        });
                    }else{
                        chart.lines.interactive(false);
                    }
                    if(scaling ==="time") {
                        chart.xScale(d3.time.scale());
                    }

                    chart.options = nv.utils.optionsFunc.bind(chart);
                    chart.xAxis
                        .showMaxMin(!!thisWidget.xAxisMinMaxVisible)
                        .rotateLabels(thisWidget.labelAngle) // Want longer labels? Try rotating them to fit easier.
                        .axisLabel(thisWidget.showAxisLabels ? thisWidget.xAxisLabel : '')
                        .tickPadding(10);

                    if (thisWidget.xAxisIntervals !== "auto") {
                        chart.xAxis.ticks(data[0].values.length);
                    }

                    if(scaling==="time") {
                        chart.xAxis.tickFormat(function (d) {
                                if (thisWidget.timeScale === 'auto') {
                                    return tickMultiFormat(new Date(d));
                                } else {
                                    return d3.time.format(thisWidget.timeFormat)(new Date(d));
                                }
                        });
                    }
                    if(scaling==="linear"){
                        chart.xAxis.tickFormat(d3.format('.0d'));
                    }

                       // .tickValues(function(values) {
                       //     return _.map(values[0].values, function(v) {
                       //         return new Date(v.x);
                       //     });
                       // })

                    chart.yAxis
                        .showMaxMin(!!thisWidget.yAxisMinMaxVisible)
                        .axisLabel(thisWidget.showAxisLabels ? thisWidget.yAxisLabel : '')
                        //.tickFormat(d3.format('.02f')) //floating point/money 'd' for integers
                        .tickFormat(d3.format('.02f'));
                    thisWidget.yAxisIntervals==="per" ? chart.yAxis.ticks(data[0].values.length): chart.yAxis.ticks();
                    // data applied to chart
                    thisWidget.chartData = d3.select(chartContainerId).datum(data);
                    thisWidget.chartData.transition().duration(thisWidget.duration).call(chart);
                    $('.xy-tooltip').remove();

                    doUpdateStyles();

                    if(!resizeHandler){
                        resizeHandler = nv.utils.windowResize(function () {
                            chart.update();
                        });
                    }

                    chart.dispatch.on('stateChange', function (e) {
                        chart.useInteractiveGuideline(false);
                        updateStyles(e)
                    });
                });
            }

            // triggered by chart clicks
            function handleClick() {
                var fieldName = thisWidget.chartSeries[valueUnderMouse.series].field;
                var seriesData = thisWidget.chartSeries[valueUnderMouse.series].data;

                for (var i = 0;i<seriesData.length;i++){
                    if(seriesData[i][fieldName]===valueUnderMouse.value){
                        // this is the row in datasource series
                        clickedRowId = i;
                        thisWidget.setSeriesSelection();
                    }
                }
            }

            // triggered by legend click
            function updateStyles(e) {
                setTimeout(function () {
                    doUpdateStyles();
                }, thisWidget.duration);
            }

            function doUpdateStyles() {
                d3.selectAll(widgetContainerId + ' .nv-background rect')
                    .style("fill", chartStyles.chartBackground);
                d3.selectAll(widgetContainerId + '-chart .nv-line')
                    .style("fill", "none");
                d3.selectAll(widgetContainerId+'-chart text')
                    .style("fill", chartStyles.text);
                d3.selectAll(widgetContainerId+'-chart nv-legend-text')
                    .style("fill", chartStyles.text);
                d3.selectAll(widgetContainerId+'-chart line')
                    .style("stroke", chartStyles.gridStyle);
                d3.selectAll(widgetContainerId+'-chart path')
                    .style("cursor","pointer")
                    .style("pointer-events", "all")
                    .on('click',function(e){
                        handleClick();
                    });

                chart.useInteractiveGuideline(thisWidget.showInteractiveGuideline);
            }
        };

        this.update = function (data){
            // Update the SVG with the new data and call chart
            thisWidget.chartData.datum(data).transition().duration(500).call(chart);
            if(!resizeHandler){
                resizeHandler = nv.utils.windowResize(chart.update);
            }
        };

        // stub in case we want to have sorting options later
        function sortBy(data, sortProp){
            // get data field name from sortProp which is name of property holding field name

            function sortByProperty(property) {
                'use strict';
                return function (a, b) {
                    var sortStatus = 0;
                    if (a[property] < b[property]) {
                        sortStatus = -1;
                    } else if (a[property] > b[property]) {
                        sortStatus = 1;
                    }

                    return sortStatus;
                };
            }

            return data.sort(sortByProperty(sortProp));
        }

        this.createScaleControls = function(){
            if(scaleControlsCreated) {
                return;
            }else {
                var controlsWrap = d3.select(chartContainerId).append("g")
                    .attr("class", "nv-controlsWrap nvd3-svg")
                    .attr("transform", "translate(120,14)");

                var controlLegend = controlsWrap.append("g")
                    .attr("class", "nvd3 nv-legend");

                var controlTime = controlLegend.append("g")
                    .attr("class", "nv-series")
                    .attr("id", "controlTime")
                    .style("cursor", "pointer")
                    .on('click', function () {
                        d3.select("#linearSymbol").attr("fill", "transparent");
                        d3.select("#timeSymbol").attr("fill", "rgb(68,68,68)");
                        scaling = "time";
                        if(! isInHiddenTab) {
                            thisWidget.liveData = this.processDataset();
                        }
                    });

                var controlLinear = controlLegend.append("g")
                    .attr("class", "nv-series")
                    .attr("id", "controlLinear")
                    .attr("transform", "translate(90,0)")
                    .style("cursor", "pointer")
                    .on('click', function () {
                        d3.select("#timeSymbol").attr("fill", "transparent");
                        d3.select("#linearSymbol").attr("fill", "rgb(68,68,68)");
                        scaling = "linear";
                        if(! isInHiddenTab) {
                            thisWidget.liveData = this.processDataset();
                        }
                    });

                controlTime.append("circle")
                    .attr("class", "nv-legend-symbol")
                    .attr("id", "timeSymbol")
                    .attr("r", 5)
                    .attr("stroke-width", 2)
                    .attr("fill", "rgb(68,68,68)")
                    .attr("stroke", "rgb(68,68,68)");

                controlLinear.append("circle")
                    .attr("class", "nv-legend-symbol")
                    .attr("id", "linearSymbol")
                    .attr("r", 5)
                    .attr("stroke-width", 2)
                    .attr("fill", "transparent")
                    .attr("stroke", "rgb(68,68,68)");

                controlLinear.append("text")
                    .attr("text-anchor", "start")
                    .attr("class", "nv-legend-text")
                    .attr("transform", "translate(8,5)")
                    .text("Linear Scale");
                scaleControlsCreated = true;
            }
        };

        this.dblClickHandler = function(){
            thisWidget.jqElement.triggerHandler('DoubleClicked');
        };

        this.showEmptyChart = function (message) {
            TW.log.warn(message);
            /*
            var chartWidgetPos;
            if($(widgetContainerId)) {
                chartWidgetPos = $(widgetContainerId).offset();
            }
            d3.select(chartContainerId).append("rect")
                .attr({"class": "tick", "id": chartContainer+"_chartBorder"})
                .attr({"x": chartWidgetPos.left, "y": chartWidgetPos.top, "width": $(widgetContainerId).width(), "height": $(widgetContainerId).height()})
                .style({"fill": "gray", "stroke": chartStyles.gridStyle});
            var label1 = Encoder.htmlEncode('Okay');
            var button1default = widgetProperties['DefaultConfirmationButton'] === 'button1';
            var button1cancel = true;
            var buttons = {};
            buttons[label1] = {
                'class': 'blue',
                'action': function () {
                    if (!button1cancel) {
                        thisWidget.jqElement.triggerHandler('Clicked');
                    }
                },
                'default': button1default
            };
            $.confirm({
                'title': Encoder.htmlEncode('LineChart Configuration'),
                'message': Encoder.htmlEncode(message),
                'buttons': buttons
            });
            */
        };

        // this probably has to be run mutiple times due to dataLabel being  a dynamic runtime property
        // check for duplicate dataLabels and append numeric suffix if needed
        this.forceUniqueValues = function (dataLabels) {
            var data = dataLabels,
                result = data.map(function (item) {
                    return this[item].count === 1 ? item : item + '-' + ++this[item].index;
                }, data.reduce(function (retVal, item) {
                    retVal[item] = retVal[item] || {count: 0, index: 0};
                    retVal[item].count++;
                    return retVal;
                }, {}));
            return result;
        };

        /*
         note this section is ripped from nvd3 in order to customize it
         nvd3 version 1.8.1 (https://github.com/novus/nvd3) 2015-06-15
         Tooltip data. If data is given in the proper format, a consistent tooltip is generated.
         Example Format of data:
         {
         key: "Date",
         value: "August 2009",
         series: [
         {key: "Series 1", value: "Value 1", color: "#000"},
         {key: "Series 2", value: "Value 2", color: "#00f"}
         ]
         }
*/

        //Format function for the tooltip values column
        this.valueFormatter = function(d,i) {
            return d;
        };

        //Format function for the tooltip header value.
        this.headerFormatter = function(d) {
            return d;
        };

        this.keyFormatter = function(d, i) {
            return d;
        };

        this.tooltipGenerator = function(d) {
            var headerEnabled = true;
            if (d === null) {
                return '';
            }

            var table = d3.select(document.createElement("table"));
            if (headerEnabled) {
                var theadEnter = table.selectAll("thead")
                    .data([d])
                    .enter().append("thead");

                theadEnter.append("tr")
                    .append("td")
                    .attr("colspan", 3)
                    .append("strong")
                    .classed("x-value", true)
                    //.html(headerFormatter(d.value)); // default is to use x value, which has no meaning
                    // use x-axis label, assume it id's "something" in quantity of something
                    .html(thisWidget.headerFormatter(thisWidget.xAxisLabel));
            }

            var tbodyEnter = table.selectAll("tbody")
                .data([d])
                .enter().append("tbody");
            var rowEnterCounter = 0;
            var trowEnter = tbodyEnter.selectAll("tr")
                .data(function(p) { return p.series})
                .enter()
                .append("tr")
                .classed("highlight", function(p, i) {
                        if(p.highlight){
                            //console.log("is p.highlight: "+ p.highlight);
                            valueUnderMouse.series = rowEnterCounter;
                            valueUnderMouse.value = p.value;
                            rowEnterCounter = 0;
                        }else{
                            //console.log("no p.highlight: "+ p.highlight);
                            rowEnterCounter++;
                        }

                    return p.highlight
                });

            trowEnter.append("td")
                .classed("legend-color-guide",true)
                .append("div")
                .style("background-color", function(p) { return p.color});

            trowEnter.append("td")
                .classed("key",true)
                .html(function(p, i) {return thisWidget.keyFormatter(p.key, i)});

            trowEnter.append("td")
                .classed("value",true)
                .html(function(p, i) { return thisWidget.valueFormatter(p.value, i) });

            trowEnter.selectAll("td").each(function(p) {
                if (p.highlight) {
                    var opacityScale = d3.scale.linear().domain([0,1]).range(["#fff",p.color]);
                    var opacity = 0.6;
                    d3.select(this)
                        .style("border-bottom-color", opacityScale(opacity))
                        .style("border-top-color", opacityScale(opacity))
                    ;
                }
            });

            var html = table.node().outerHTML;
            if (d.footer !== undefined)
                html += "<div class='footer'>" + d.footer + "</div>";
            return html;

        };

        //single item selection support to start off
        this.setSeriesSelection = function() {
            selectedRowIndices = [];
            //var selectedRowIndices = updatePropertyInfo.SelectedRowIndices;
            selectedRowIndices.push(clickedRowId);
            thisWidget.updateSelection('Data', selectedRowIndices);
        };

        this.beforeDestroy = function () {
            if(resizeHandler){
                resizeHandler.clear();
                resizeHandler = null;
            }
            try {
                thisWidget.jqElement.off();
            } catch (err) {
                TW.log.error('Error in TW.Runtime.Widgets.button.beforeDestroy', err);
            }
        };

    };
}());
